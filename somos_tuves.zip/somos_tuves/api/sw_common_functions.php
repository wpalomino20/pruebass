<?php 

function datosParaStatement($columnas_info) {
    /*
    Ejemplo de arreglo:
    $columnas_info = array(
        'columna_bd' => array('type' => 's|i|d', 'placeholder' => '?|F', 'value' => &por_referencia),
    )
    */
    $datos = array(
        'columnas' => '',
        'placeholders' => '',
        'tipos' => '',
        'valores' => array(),
        'params' => array()
    );

    $datos['columnas'] = implode(",", array_keys($columnas_info));
    foreach ($columnas_info as $col_nombre => $col_info){ 
        if ($col_info['placeholder'] == '?') {
            $datos['placeholders'] .= $col_info['placeholder'].",";
            $datos['valores'][] = &$col_info['value'];
            $datos['tipos'] .= $col_info['type'];

        } else if ($col_info['placeholder'] == 'F'){
            $datos['placeholders'] .= $col_info['value'].",";
        }
    }
    if (strlen($datos['placeholders']) > 0) $datos['placeholders'] = trim($datos['placeholders'], ",");
    $datos['params'][] = $datos['tipos'];
    $datos['params'] = array_merge($datos['params'], $datos['valores']);

    return $datos;
}

function obtenerIPCliente(){
	// return $_SERVER['HTTP_X_FORWARDED_FOR'];
	// exit();
	
	
    if( isset($_SERVER['HTTP_X_FORWARDED_FOR']) && $_SERVER['HTTP_X_FORWARDED_FOR'] != '' )
    {
        $ipCliente =
        ( !empty($_SERVER['REMOTE_ADDR']) ) ?
        $_SERVER['REMOTE_ADDR']
            :
            ( ( !empty($_ENV['REMOTE_ADDR']) ) ?
            $_ENV['REMOTE_ADDR']
                :
                "unknown" );

        $entradasL = preg_split('[, ]', $_SERVER['HTTP_X_FORWARDED_FOR']);

        reset($entradasL);

        // OLD VERSION

        // while (list(, $entradaActual) = each($entradasL))
        // {
        //     $entradaActual = trim($entradaActual);
        //     if ( preg_match("/^([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)/", $entradaActual, $listaIPs) )
        //     {
        //     $ipPrivada = array(
        //             '/^0\./',
        //             '/^127\.0\.0\.1/',
        //             '/^192\.168\..*/',
        //             '/^172\.((1[6-9])|(2[0-9])|(3[0-1]))\..*/',
        //             '/^10\..*/');

        //         $ipEncontrada = preg_replace($ipPrivada, $ipCliente, $listaIPs[1]);

        //         if ($ipCliente != $ipEncontrada)
        //         {
        //         $ipCliente = $ipEncontrada;
        //         break;
        //     }
        //     }
        // }

        // VERSION PHP 7.3.33

        foreach ($entradasL as $entradaActual) {
            $entradaActual = trim($entradaActual);
            if (preg_match("/^([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)/", $entradaActual, $listaIPs)) {
                $ipPrivada = array(
                    '/^0\./',
                    '/^127\.0\.0\.1/',
                    '/^192\.168\..*/',
                    '/^172\.((1[6-9])|(2[0-9])|(3[0-1]))\..*/',
                    '/^10\..*/'
                );
        
                $ipEncontrada = preg_replace($ipPrivada, $ipCliente, $listaIPs[1]);
        
                if ($ipCliente != $ipEncontrada) {
                    $ipCliente = $ipEncontrada;
                    break;
                }
            }
        }
    }
    else
    {
        $ipCliente =
            ( !empty($_SERVER['REMOTE_ADDR']) ) ?
                $_SERVER['REMOTE_ADDR']
                :
                ( ( !empty($_ENV['REMOTE_ADDR']) ) ?
                $_ENV['REMOTE_ADDR']
                :
                "unknown" );
    }

    return $ipCliente;
	
}