<?php
require_once __DIR__ . '/../pass_user_t2.php';
require_once __DIR__ . '/../app/Models/DB.php';

use App\Models\DB;

$db = new DB();

$db->statement("
    ALTER TABLE procedimientos
    ADD COLUMN pais VARCHAR(50) NULL AFTER activo
");

$res = $db->statement("
    UPDATE procedimientos
    SET pais = 'chile'
    WHERE pais IS NULL
");

echo "Migración OK. Registros actualizados: {$res->affected_rows}\n";
