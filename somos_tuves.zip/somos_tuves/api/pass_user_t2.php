<?php


$host='rds-kt2-cluster.cluster-cn4c8uwiy2u3.us-east-1.rds.amazonaws.com';
/*
$user = getenv('BD_INTRANET_USER');
$pass = getenv('BD_INTRANET_PSWD');*/
$user = "agamonal"; //getenv('BD_INTRANET_USER');
$pass = "yp!rAM_VH4Q_"; //getenv('BD_INTRANET_PSWD');
$db = 'PCE';

session_start();

?>