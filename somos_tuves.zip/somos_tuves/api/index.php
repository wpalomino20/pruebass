<?php

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ERROR);
date_default_timezone_set('America/Santiago');

use App\Http\Route;

header("Access-Control-Allow-Origin: *");
header('Access-Control-Allow-Methods: post, POST,OPTIONS');
header('Access-Control-Allow-Headers: *');
// header("Access-Control-Allow-Headers: *");
// header('Access-Control-Allow-Credentials: true');
########################    Utils     ########################
require_once "pass_user_t2.php"; 
require_once "app/autoloader.php";
require_once "sw_common_functions.php";


set_exception_handler(array('App\Exceptions\ExceptionHandler','handler'));
##############################################################
# Los controladores se encuentran en t2/app/Controllers
##############################################################

App\Controllers\GeneralController::routes();
/*
-----------
 Ajustes 
-----------
*/
Route::post("/ajustes/mantenimiento-menu",array("App\Controllers\Ajustes\AgregarMenuController","index"));
Route::post("/ajustes/mantenimiento-menu/store",array("App\Controllers\Ajustes\AgregarMenuController","store"));
Route::post("/ajustes/mantenimiento-menu/edit",array("App\Controllers\Ajustes\AgregarMenuController","edit"));
Route::post("/ajustes/mantenimiento-menu/update",array("App\Controllers\Ajustes\AgregarMenuController","update"));
Route::post("/ajustes/mantenimiento-menu/delete",array("App\Controllers\Ajustes\AgregarMenuController","destroy"));



Route::post("auth/signin",array('App\Controllers\Auth\AuthController','signin'));
Route::post("auth/user",array('App\Controllers\Auth\AuthController','validateUser'));
Route::post("auth/signout",array('App\Controllers\Auth\AuthController','revokeToken'));
Route::post("auth/reset",array('App\Controllers\Auth\AuthController','resetPassword'));
Route::post("auth/prueba",array('App\Controllers\Auth\AuthController','permisosSesion'));

/* ---------------------- PERMISOS / PERFILES -------------------------- */
Route::post("ajustes/permisos-perfiles/roles", array("App\Controllers\Ajustes\GestorUsuariosController", "getRoles"));
Route::post("ajustes/permisos-perfiles/permission", array("App\Controllers\Ajustes\GestorUsuariosController", "getPermissions"));
Route::post("ajustes/permisos-perfiles/save", array("App\Controllers\Ajustes\GestorUsuariosController", "saveRolesPermissions"));
Route::post("ajustes/permisos-perfiles/update", array("App\Controllers\Ajustes\GestorUsuariosController", "updateRolesPermissions"));
/* --------------------------------------------------------------------- */

Route::post("ajustes/permisos",array('App\Controllers\Ajustes\PermisosController','listarModulos_V2'));
Route::post("ajustes/permisos/test",array('App\Controllers\Ajustes\PermisosController','listarModulosTest'));

Route::post("ajustes/permisos/usuario",array('App\Controllers\Ajustes\PermisosController','listarModulosUsuario_V2'));
Route::post("ajustes/permisos/usuario/dev",array('App\Controllers\Ajustes\PermisosController','listarModulosUsuarioDev'));

Route::post("ajustes/permisos/adicionar-permisos",array('App\Controllers\Ajustes\PermisosController','adicionarPermisos'));
Route::post("ajustes/permisos/adicionar-permisos-xls",array('App\Controllers\Ajustes\PermisosController','adicionarPermisosExcel'));
Route::post("ajustes/permisos/asignar-permisos",array('App\Controllers\Ajustes\PermisosController','asignarPermisos'));
Route::post("ajustes/permisos/asignar-permisos-xls",array('App\Controllers\Ajustes\PermisosController','asignarPermisosExcel'));


Route::post("ajustes-kt2/permisos",array('App\Controllers\Ajustes\PermisosControllerKT2','listarModulos'));
Route::post("ajustes-kt2/permisos/usuario",array('App\Controllers\Ajustes\PermisosControllerKT2','listarModulosUsuario'));
Route::post("ajustes-kt2/permisos/adicionar-permisos",array('App\Controllers\Ajustes\PermisosControllerKT2','adicionarPermisos'));
Route::post("ajustes-kt2/permisos/adicionar-permisos-xls",array('App\Controllers\Ajustes\PermisosControllerKT2','adicionarPermisosExcel'));
Route::post("ajustes-kt2/permisos/asignar-permisos",array('App\Controllers\Ajustes\PermisosControllerKT2','asignarPermisos'));
Route::post("ajustes-kt2/permisos/asignar-permisos-xls",array('App\Controllers\Ajustes\PermisosControllerKT2','asignarPermisosExcel'));

Route::post("ajustes/gestor-usuarios",array('App\Controllers\Ajustes\GestorUsuariosController','listarUsuarios'));
Route::post("ajustes/gestor-usuarios/disponibilidad",array('App\Controllers\Ajustes\GestorUsuariosController','verificarDisponibiladUsuario'));
Route::post("ajustes/gestor-usuarios/crear",array('App\Controllers\Ajustes\GestorUsuariosController','crearUsuario'));
Route::post("ajustes/gestor-usuarios/editar",array('App\Controllers\Ajustes\GestorUsuariosController','editarUsuario'));
Route::post("ajustes/gestor-usuarios/reset",array('App\Controllers\Ajustes\GestorUsuariosController','resetearPassword'));
Route::post("ajustes/gestor-usuarios/desactivar",array('App\Controllers\Ajustes\GestorUsuariosController','desactivarUsuario'));
Route::post("ajustes/gestor-usuarios/eliminar",array('App\Controllers\Ajustes\GestorUsuariosController','eliminarUsuario'));
Route::post("ajustes/gestor-usuarios/validar-excel",array('App\Controllers\Ajustes\GestorUsuariosController','validarUsuariosExcel'));
Route::post("ajustes/gestor-usuarios/validar-usuario",array('App\Controllers\Ajustes\GestorUsuariosController','validarUsuario'));
Route::post("ajustes/gestor-usuarios/creacion-mavisa",array('App\Controllers\Ajustes\GestorUsuariosController','crearUsuariosMasivo'));
Route::excel("ajustes/gestor-usuarios/exportar",array('App\Controllers\Ajustes\GestorUsuariosController','exportarUsuarios'),"usuarios");
Route::excel("ajustes/gestor-usuarios/exportar-creados",array('App\Controllers\Ajustes\GestorUsuariosController','exportarUsuariosCreados'),"usuarios_creados");
Route::excel("ajustes/gestor-usuarios/exportar-accion",array('App\Controllers\Ajustes\GestorUsuariosController','exportarAcciones'),"informe_acciones");
Route::excel("ajustes/gestor-usuarios/exportar-permisos",array('App\Controllers\Ajustes\GestorUsuariosController','exportarPermisosUsuario'),"permisos_usuarios");

Route::post("ajustes/mantenedor-perfil-empresa-aliada", array('App\Controllers\Ajustes\Mantenedor\EmpresaAliadaController', 'index'));
Route::post("ajustes/mantenedor-perfil-empresa-aliada-store", array('App\Controllers\Ajustes\Mantenedor\EmpresaAliadaController', 'store'));
Route::post("ajustes/mantenedor-perfil-empresa-aliada-update", array('App\Controllers\Ajustes\Mantenedor\EmpresaAliadaController', 'update'));
Route::post("ajustes/mantenedor-perfil-empresa-aliada-destroy", array('App\Controllers\Ajustes\Mantenedor\EmpresaAliadaController', 'destroy'));

Route::post("ajustes/mantenedor-perfiles", array('App\Controllers\Ajustes\Mantenedor\PerfilUsuarioController', 'init_perfiles'));
Route::post("ajustes/mantenedor-perfiles-store", array('App\Controllers\Ajustes\Mantenedor\PerfilUsuarioController', 'perfilesStore'));
Route::post("ajustes/mantenedor-perfiles-update", array('App\Controllers\Ajustes\Mantenedor\PerfilUsuarioController', 'perfilesUpdate'));
Route::post("ajustes/mantenedor-perfiles-destroy", array('App\Controllers\Ajustes\Mantenedor\PerfilUsuarioController', 'perfilesDestroy'));

Route::post("ajustes/mantenedor/modelos", array('App\Controllers\Ajustes\Mantenedor\UsuariosModeloController', 'listarUsuariosModelo'));
Route::post("ajustes/mantenedor/modelos/guardar", array('App\Controllers\Ajustes\Mantenedor\UsuariosModeloController', 'guardarPermisoModelo'));
Route::post("ajustes/mantenedor/modelos/desactivar", array('App\Controllers\Ajustes\Mantenedor\UsuariosModeloController', 'desactivarModelo'));

Route::post("ajustes/mantenedor/equipos", array('App\Controllers\Ajustes\Mantenedor\EquiposController', 'listarEquipos'));
Route::post("ajustes/mantenedor/equipos/guardar", array('App\Controllers\Ajustes\Mantenedor\EquiposController', 'guardarEquipo'));
Route::post("ajustes/mantenedor/equipos/estado", array('App\Controllers\Ajustes\Mantenedor\EquiposController', 'cambiarEstadoEquipo'));



Route::post("Hogar/Procedimientos/listarProcedimientos", array('App\Controllers\Hogar\ProcedimientosController', 'listarProcedimientos'));
Route::post("Hogar/Procedimientos/searchProcedimiento", array('App\Controllers\Hogar\ProcedimientosController', 'searchProcedimiento'));
Route::post("Hogar/Procedimientos/searchProcedimientoFiles", array('App\Controllers\Hogar\ProcedimientosController', 'searchProcedimientoFiles'));
Route::post("Hogar/Procedimientos/cargarProcedimiento", array('App\Controllers\Hogar\ProcedimientosController', 'cargarProcedimiento'));
Route::post("Hogar/Procedimientos/dynamicUploadService", array('App\Controllers\Hogar\ProcedimientosController', 'dynamicUploadService'));

Route::post("Hogar/Procedimientos/grabarSatisfaccion", array('App\Controllers\Hogar\ProcedimientosController', 'grabarSatisfaccion'));
Route::post("Hogar/Procedimientos/uploadImg", array('App\Controllers\Hogar\ProcedimientosController', 'uploadImg'));
Route::post("Hogar/Procedimientos/buscarProcedimientoList", array('App\Controllers\Hogar\ProcedimientosController', 'buscarProcedimientoList'));


/*
    #############################
        LIST PROCEDIMIENTOS
    #############################
*/
Route::post("Hogar/Procedimientos/listarProcedimientos/save-file", array('App\Controllers\Hogar\ProcedimientosController', 'saveFile'));
Route::post("Hogar/Procedimientos/searchProcedimientoFiles-dev", array('App\Controllers\Hogar\ProcedimientosController', 'searchProcedimientoFilesDev'));
Route::post("Hogar/Procedimientos/listarProcedimientos/save-item", array('App\Controllers\Hogar\ProcedimientosController', 'saveItem'));
Route::post("Hogar/Procedimientos/listarProcedimientos/delete-item", array('App\Controllers\Hogar\ProcedimientosController', 'deleteItem'));
Route::post("Hogar/Procedimientos/listarProcedimientos/delete-subitem", array('App\Controllers\Hogar\ProcedimientosController', 'deleteSubItem'));
Route::post("Hogar/Procedimientos/listarProcedimientos/calificaciones", array('App\Controllers\Hogar\ProcedimientosController', 'getCalification'));
Route::post("Hogar/Procedimientos/listarProcedimientos/calificaciones-save", array('App\Controllers\Hogar\ProcedimientosController', 'saveCalification'));
Route::post("Hogar/Procedimientos/listarProcedimientos/search", array('App\Controllers\Hogar\ProcedimientosController', 'searchProcedemiento'));


/*
    #############################
        NOTIFICACIONES
    #############################
*/

Route::post("hogar/procedimientos/eventListener", array('App\Controllers\Hogar\ListenerProcedimentos', 'index'));

$_REQUEST["path"]=substr($_ENV['PATH_INFO'],1);

/*if (isset($_SERVER['REQUEST_URI'])) {
    $_REQUEST["path"] = str_replace("/SOMOS_TUVES_SERVER/somos_tuves/api/index.php/", "", $_SERVER['REQUEST_URI']);
} else {
    $_REQUEST["path"] = "";
}*/

Route::run();



