<?php
namespace App\Controllers\Auth;

use App\Models\AuthModel;
use App\Controllers\Controller;
use App\Models\Session;
use App\Models\DB;
use App\Utils\Password;

class AuthController extends Controller{

    private $model;
    private $db;
    public function __construct()
    {
        $this->model = new AuthModel();
        $this->middleware()->except("signin","pruebaReutilizar","permisosSesion");
        $this->db = new DB();
    }
    public function signin($request){
        $validCredentials = $this->model
                                 ->validUsernameAndPassword($request->username,$request->password);
        if(!$validCredentials){
            return array(
                "message" => "Usuario o contraseña incorrectas",
                "status" => false,
            );
        }
        $validToken = $this->model->userHasValidToken();

        if($validToken){
            return $this->model
                        ->renovarToken()
                        ->get();
        }
        return $this->model
                    ->generateNewToken($request->all())
                    ->get();
    }
    public function validateUser($request){
        
        // $headerRequest = apache_request_headers();
        // $token = $headerRequest["authorization"];
        $token = $request->Authorization;
        $validation = $this->model->validToken($token);

        if($validation || Session::authenticated()){
            Session::refresh();
            return array(
                "message" => "Informacion",
                "status" => true,
                "data" => Session::user()
            );
        }
        return array(
            "message" => "Invalid Credentials",
            "status" => false,
        );
        
    }
    public function revokeToken($request){
        // $headerRequest = apache_request_headers();
        // $token = $headerRequest["authorization"];
        $token = $request->Authorization;
        $res = $this->model->revokeToken($token);
        unset($res->affeted_rows);
        unset($res->insert_id);
        return $res;
    }

    public function resetPassword($request){
        $query = "SELECT pass FROM t2_web_extranet.user_tec WHERE `user` = :usuario";
        $password_hash =  $this->db->find($query,array(
            "usuario" => Session::user()->username,
        ))->data["pass"];

        if(!Password::validate($request->password_old,$password_hash)){
            return array(
                "status" => false,
                "message" => "La clave actual no coincide",
                "errors" => array(
                    "password_old" => "Clave actual incorrecta"
                )
            );
        }

        if($request->password_new != $request->password_confirm){
            return array(
                "status" => false,
                "message" => "La clave actual no coincide",
                "errors" => array(
                    "password_new" => "Las claves no coinciden",
                    "password_confirm" => "Las claves no coinciden",
                )
            );
        }

        $query = "UPDATE t2_web_extranet.user_tec SET pass = :password  WHERE `user` = :usuario";
        $resp = $this->db->statement($query,array(
            ":password" => Password::hash($request->password_new),
            ":usuario" => Session::user()->username,
        ));
        $resp->message = "Se actualizo la clave";
        $resp->usuer = Session::user()->username;
        return $resp;
    }
}
