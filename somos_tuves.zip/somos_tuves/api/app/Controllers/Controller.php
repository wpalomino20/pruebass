<?php
namespace App\Controllers;

use App\Exceptions\NotAuthenticatedException;
use App\Models\Session;

abstract class Controller{

    private $protectedMethods = array();
    private $exceptionRoutes = array();
    private $hasMiddleware = false;
    protected function middleware(){
        $this->hasMiddleware = true;
        return $this;
    }
    protected function only(){
        $args = func_get_args();
        $this->protectedMethods = $args;
    }
    protected function except(){
        $args = func_get_args();
        $this->exceptionRoutes = $args;
    }
    public function validateMiddleware($method){
        if($this->hasMiddleware && !Session::authenticated()){
            if(count($this->protectedMethods) == 0 && !in_array($method,$this->exceptionRoutes)){
                throw new NotAuthenticatedException();
            }
            if(count($this->protectedMethods) != 0 && in_array($method,$this->protectedMethods)){
                throw new NotAuthenticatedException();
            }
        }
    }
    public function view($path, $params = array()){
        if(count($params) > 0){
            extract($params,EXTR_OVERWRITE);
        }
        $root_path = $_SERVER["DOCUMENT_ROOT"];
        $view_path = "{$root_path}/t2/app/assets/views/{$path}.php";
        if(!file_exists($view_path)){
            return "<h1>No existe la pagina</h1>";
        }

        ob_start();
        require_once $view_path;
        $output = ob_get_clean();
        return $output;

    }
    public function displayErrors(){
        ini_set('display_errors', '1');
        ini_set('display_startup_errors', '1');
        error_reporting(E_ALL);
    }
    public function requestMemoryLimit($limit = -1){
        ini_set("memory_limit",$limit);
    }

}