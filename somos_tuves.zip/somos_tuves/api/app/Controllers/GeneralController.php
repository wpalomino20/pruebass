<?php
namespace App\Controllers;

use App\Models\DB;
use App\Http\Request;
use App\Controllers\Controller;
use App\Models\Session;
use App\Models\T4\CierreTipoTrabajo;
use App\Models\GeneralModel;
use App\Http\Route;
use Exception;

class GeneralController extends Controller{

    private $db;
    private $model;
    public function __construct(){
        $this->db = new DB();
        $this->middleware()->only("calidadTecnicoSesion");
        $this->model = new GeneralModel();
    }

    public function getInfoCierreTipoTrabajo() {
        try {
            return array(
                'status' => true,
                'data' => CierreTipoTrabajo::get(),
                'msg' => "OK"
            );
        } catch (\Exception $e) {
            return array(
                'status' => true,
                'data' => array(),
                'msg' => $e->getMessage()
            );
        }
    }

    public function calidadTecnicoSesion($request){
        $sql = "SELECT rut_tec,mes,instalacion,reparacion,`upgrade`,calidad_terreno, cuartil_tecnico 
                FROM lista_negra_tecnicos
                WHERE 1
                -- AND cuartil_tecnico = 5 
                AND rut_tec = :rut";
        $res = $this->db->find($sql,array(
            ":rut" => Session::user()->dni,
        ));
        $res->data["instalacion"] = number_format($res->data["instalacion"],2);
        $res->data["reparacion"] = number_format($res->data["reparacion"],2);
        $res->data["upgrade"] = number_format($res->data["upgrade"],2);
        $res->data["calidad_terreno"] = number_format($res->data["calidad_terreno"],2);
        return $res;
    }
    public function buscarUsuario(Request $request){
        $usuario = $request->usuario;
        if($usuario == "") return array();
        $usuario = "%$usuario%";
        $sql = "SELECT user,rut_tecnico,CONCAT_WS(' ',nombre_tec,ape_tec) nombres 
                FROM user_tec 
                WHERE (`user` LIKE :usuario OR rut_tecnico LIKE :rut)
                AND activo = 1";
        $data = $this->db->select($sql, array(
            "usuario" => $usuario,
            "rut" => $usuario,
        ));
        return $data;
    }
    public function listarAliados(){
        return $this->model->listarAliados();
    }
    public function listarPerfiles(){
        return $this->model->listarPerfiles();
    }

    public function listarEmpresasAliadas(){
        return $this->model->listarEmpresasAliadas();
    }
    public function listarUsuariosPorPerfil($request){
        $sql = "SELECT user,CONCAT_WS(' ',nombre_tec,ape_tec) nombres,rut_tecnico FROM user_tec WHERE tipo_user = :perfil";

        $exe = $this->db->select($sql,array(
            ":perfil" => $request->perfil
        ));

        return $exe;
    }

    public function actualizarVisitas($request){
        $path = trim($request->searchPath,"/");
        $query = "SELECT s2.id,s1.id id_padre FROM t2_web_extranet.t2_menu s2
                  INNER JOIN t2_web_extranet.t2_menu s1 ON s2.menu_id_padre = s1.id
                  WHERE CONCAT_WS('/',s1.ruta,s2.ruta) LIKE :path";
        $res =  $this->db->find($query,array(
            ":path" => $path . "%",
        ));

        $queryUpt = "UPDATE t2_web_extranet.t2_menu
                     SET contador = (contador + 1),
                     fecha_ultima_visita = NOW()
                     WHERE id IN (:id,:id_padre)";

        return $this->db->statement($queryUpt,array(
            ":id" => $res->data["id"],
            ":id_padre" =>  $res->data["id_padre"],
        ));

    }
    public function regionesComunas(){
        $query = "SELECT * FROM regiones_comunas WHERE estado = 1";
        $res = $this->db->select($query);
        $regiones = array();
        foreach($res->data as $row){
            $regiones[$row["comuna"]] = $row["region"];
        }

        $res->data = $regiones;
        return $res;
        
    }
    
    public function listarEquipos(){
        $query = "SELECT tipo_equipo n1 ,modelo n2,doc_sis n3 FROM t2_equipos WHERE estado = 1 ";
        $equipos = $this->db->select($query)->data;

        foreach($equipos as $row){
            $rowEquipo[$row["n1"]]["value"] = $row["n1"];
            $rowEquipo[$row["n1"]]["options"][$row["n2"]]["value"] =  $row["n2"];
            $rowEquipo[$row["n1"]]["options"][$row["n2"]]["options"][$row["n3"]]["value"] = $row["n3"];
        }
        $newArray = array();
        $ind = array(
            "n1" => 0,
            "n2" => 0,
            "n3" => 0,
        );
        foreach($rowEquipo as $keyN1 => $equipo){
            $newArray[$ind["n1"]]["value"] = $equipo["value"];
            foreach($equipo["options"] as $keyN2 => $modelo){
                $newArray[$ind["n1"]]["options"][$ind["n2"]]["value"] = $keyN2;
                foreach($modelo["options"] as $keyN3 => $doc_sis){
                    if(!!$doc_sis["value"]){
                        $newArray[$ind["n1"]]["options"][$ind["n2"]]["options"][$ind["n3"]] = $doc_sis;
                        $ind["n3"]++;
                    }
                }
                $ind["n2"]++;
                $ind["n3"] = 0;
            }
            $ind["n1"]++;
            $ind["n2"] = 0;
        }
        return array(
            "status" => true,
            "data" => $newArray,
            "equipos" => $rowEquipo,
        );
    }

    public function getAppVersion(){
        $fileName = $_SERVER["DOCUMENT_ROOT"]."/t2/t2_react/branches/development/index.html";
        $modifiedDate = date("Y_m_d_H_i_s");
        if(file_exists($fileName)){
            $modifiedDate = date("Y_m_d_H_i_s",filemtime($fileName));
        }
        return array(
            "modified_date" => $modifiedDate,
            "file" => $fileName,
        );
    }
    public function serial($request){
        $id = $request->id;
        return date("h{$id}mis").rand(2,2);
    }
    public function exportarComando($request){

        $controller = "App\Controllers\T4Reparacion\ExporteCierreT4Controller"; 
        $method = "exporteNuevoModeloCsvBackground";
        $desde = $request->desde;
        $hasta = $request->hasta;
        $tipo_ejecutivo = $request->tipo_ejecutivo;
        $aliado = Session::user()->aliado;
        $relativeFile = "/app/assets/excel/csv_nuevo_modelo.csv";
        $path = "/var/www/t2".$relativeFile;
        unlink($path);
        $exe = "/var/www/t2/app/Commands/SaveOutputFile.php --controller='$controller' --method='$method' --desde='$desde' --hasta='$hasta' --aliado='$aliado' --tipoEjecutivo='$tipo_ejecutivo' --path='$pathFile'";

        exec("php $exe > /dev/null &",$output);
        $http = $_SERVER["HTTPS"]== "on"?"https://":"http://";
        $host = !!$_SERVER["HTTP_X_FORWARDED_SERVER"]?$_SERVER["HTTP_X_FORWARDED_SERVER"]:$_SERVER["SERVER_NAME"];
        $folder = $_SERVER["HTTP_X_FORWARDED_SERVER"] == "t4chile.grupokonecta.com.ar" ?"":"/t2";
        $url =  $http.$host.$folder.$relativeFile;
        return array(
            "url" => $url,
            "file" => $path,
        );
    }

    public function checkFileExist($request){
        return array(
            "exists" => file_exists($request->file),
        );
    }

    public static function routes(){
        Route::post("general/calidad-tecnico/",array('App\Controllers\GeneralController','calidadTecnicoSesion'));
        Route::post("general/usuario",array('App\Controllers\GeneralController','buscarUsuario'));
        Route::post("general/aliados",array('App\Controllers\GeneralController','listarEmpresasAliadas'));
        Route::post("general/cierre-tipo-trabajo",array('App\Controllers\GeneralController','getInfoCierreTipoTrabajo'));
        Route::post("general/perfiles",array('App\Controllers\GeneralController','listarPerfiles'));
        Route::post("general/empresas-aliadas",array('App\Controllers\GeneralController','listarEmpresasAliadas'));
        Route::post("general/perfiles/usuarios",array('App\Controllers\GeneralController','listarUsuariosPorPerfil'));
        Route::post("general/menu/visitas",array('App\Controllers\GeneralController','actualizarVisitas'));
        Route::post("general/regiones_comunas",array('App\Controllers\GeneralController','regionesComunas'));
        Route::post("general/equipos",array('App\Controllers\GeneralController','listarEquipos'));
        Route::post("general/version",array('App\Controllers\GeneralController','getAppVersion'));

        Route::post("general/save-outputfile",array('App\Controllers\GeneralController','exportarComando'));

        Route::post("general/checkfile-exist",array('App\Controllers\GeneralController','checkFileExist'));
    }
}
$arrGlobal = array();