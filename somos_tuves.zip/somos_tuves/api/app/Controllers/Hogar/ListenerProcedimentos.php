<?php

namespace App\Controllers\Hogar;

use App\Controllers\Controller;
use App\Models\DB;
use App\Models\Hogar\ProcedimientoModel;
use Exception;

class ListenerProcedimentos extends Controller {
    private $table;
    private $db;

    public function __construct() {
        $this->table = "listener_list_procedimientos";
        $this->db = new DB();
    }

    public static function listener(string $username, string $datetime, $idPro = null, string $type = "") {
        try {

            $sql = "
                INSERT INTO listener_list_procedimientos (user_update_create, date_update_create, idPro, type)
                VALUES (:user, :datetime, COALESCE(:idPro, 0), :type)
                ON DUPLICATE KEY UPDATE 
                    user_update_create = VALUES(user_update_create), 
                    type = VALUES(type), 
                    date_update_create = VALUES(date_update_create);
            ";

            $params = array(
                ":user" => $username,
                ":datetime" => $datetime,
                ":idPro" => $idPro,
                ":type" => $type
            );

            $result = (new DB())->statement($sql, $params);

            return $result->status;
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }

    public function index() {
        try {
            $dateLong = date("Y-m-d H:i:s");
            $currDate = date("Y-m-d");

            $procedimientos = array();

            $result = $this->db->select("
                SELECT
                    id,
                    user_update_create as username,
                    DATE_FORMAT(date_update_create, '%Y-%m-%d %H:%i:%s') as date,
                    idPro,
                    type,
                    TIMESTAMPDIFF(MINUTE, date_update_create, '{$dateLong}') AS dateHuman
                FROM {$this->table}
                WHERE DATE(date_update_create) = '{$currDate}'
                ORDER BY date_update_create DESC
            ");

            if(count($result->data) > 0) {
                foreach($result->data as $d) {
                    $str_date_human = "";

                    if($d['dateHuman'] == 0) {
                        $str_date_human = " Ahora ";
                    } else if ($d['dateHuman'] <= 60) {
                        $str_date_human = "{$d['dateHuman']} min";
                    } else if ($d['dateHuman'] > 60) {
                        $minutes = ceil($d['dateHuman'] % 60);
                        $hours = round($d['dateHuman'] / 60);
                        $str_date_human = "{$hours} h y {$minutes} min";
                    }

                    $procedimientos[] = array(
                        'id' => $d['id'],
                        'username' => $d['username'],
                        'type' => $d['type'],
                        'date' => $d['date'],
                        'dateHuman' => $str_date_human,
                        'procedimiento' => ProcedimientoModel::getById($d['idPro'])
                    );
                }
            }

            return array(
                'status' => true,
                'data' => $procedimientos,
                'msg' => "ok"
            );
        } catch (Exception $e) {
            return array(
                'status' => false,
                'data' => array(),
                'msg' => $e->getMessage()
            );
        }
    }
}