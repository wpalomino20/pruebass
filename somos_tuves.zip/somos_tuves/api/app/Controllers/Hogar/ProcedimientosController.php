<?php

namespace App\Controllers\Hogar;


use App\Controllers\Controller;
use App\Models\Session;
//use App\Models\Ajustes\ProcedimientosModel;
use App\Models\DB;
//use App\Utils\S3;
require_once "../composer/vendor/autoload.php";

use Aws\S3\S3Client;
use Aws\Exception\AwsException;

class ProcedimientosController extends Controller
{
	private $db;
	public $s3;
	private $table_procedimientos;
	private $table_procedimientos_detalle;
	private $table_procedimientos_encuesta;

	public function __construct()
	{
		$this->middleware();
		$this->db = new DB();
		$this->table_procedimientos = "procedimientos";
		$this->table_procedimientos_detalle = "procedimiento_detalle";
		$this->table_procedimientos_encuesta = "procedimiento_encuesta";
		//$this->s3 = new S3();
		//  $this->model = new ProcedimientosModel();
	}



	public function uploadImg($data)
	{

		$filename = $_FILES['file']['name'];
		$fileExtension = end(explode(".", $filename));
		$file		= $data->id . "." . $fileExtension;
		$url 		= date("Y") . "/" . date("m") . "/" . $file;
		$this->cargarIMG($_FILES['file'], $url);
		return $file;
	}

	public function cargarIMG($file, $url)
	{
		// Configura el cliente de S3 usando las credenciales por defecto (IAM Role, EC2, Lambda)
		$s3Client = new S3Client([
			'version' => 'latest',
			'region'  => 'us-east-1',  // Cambia a tu región
		]);

		// Datos del blob
		$bucketName = 'kt2-images';
		//$keyName = $file; //'archivo.jpg'; // Nombre del archivo en S3
		//$blob = $this->tratarImg($blobFile); //file_get_contents('php://input'); // Si estas recibiendo el blob desde una petici�n

		try {
			// Subir el archivo a S3
			$result = $s3Client->putObject([
				'Bucket' => $bucketName,
				'Key'    => $url,
				'Body' => file_get_contents($file['tmp_name']),
				'ContentType' => $file['type']
				//'Body'   => $blob,
				//'ContentType' => 'image/jpeg', // Ajusta el tipo de contenido según el archivo
				//'ACL'    => 'public-read', // Si quieres que el archivo sea accesible pblicamente
			]);

			//echo "Archivo subido exitosamente. URL: " . $result['ObjectURL'];
		} catch (AwsException $e) {
			//echo "Error subiendo archivo: " . $e->getMessage();
		}
	}


	public function tratarImg($base64Image)
	{
		// La imagen en base64 que se va a reducir
		//$base64Image = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD...'; // Ejemplo de imagen en base64

		// Remover el encabezado 'data:image/jpeg;base64,' si existe
		if (preg_match('/^data:image\/(\w+);base64,/', $base64Image, $type)) {
			$base64Image = substr($base64Image, strpos($base64Image, ',') + 1);
			//$type = strtolower($type[1]); // Tipo de imagen: jpg, png, gif, etc.
		} else {
			//throw new \Exception('El formato base64 no es correcto.');
		}

		// Decodificar la imagen base64
		$imageData = base64_decode($base64Image);
		// Crear una imagen desde los datos binarios usando GD
		$image = imagecreatefromstring($imageData);

		// Ajustar calidad a 75% para JPEG (valor entre 0 y 100)
		ob_start(); // Iniciar el buffer de salida
		imagejpeg($image, null, 75); // Guardar la imagen en el buffer con calidad reducida (75%)
		$compressedImageData = ob_get_contents(); // Obtener la imagen del buffer
		ob_end_clean(); // Limpiar el buffer de salida

		// Liberar memoria
		imagedestroy($image);
		return $compressedImageData;
	}

	public function obtenerIMG($url)
	{

		// Configura el cliente de S3 usando las credenciales por defecto (IAM Role, EC2, Lambda)
		$s3Client = new S3Client([
			'version' => 'latest',
			'region'  => 'us-east-1',  // Cambia a tu región
		]);


		// Nombre del bucket y la clave del archivo en S3
		$bucketName = 'kt2-images';
		$keyName = $url; // Nombre del archivo en S3

		try {
			// Obtener el archivo de S3
			$result = $s3Client->getObject([
				'Bucket' => $bucketName,
				'Key'    => $keyName
			]);

			// Convertir el contenido de la imagen en base64
			$imageData = base64_encode($result['Body']);
			$contentType = $result['ContentType'];

			// Crear una URL de datos
			return $dataUrl = "data:{$contentType};base64,{$imageData}";

			// Mostrar la imagen como Data URL
			//echo '<img src="' . $dataUrl . '" alt="Imagen desde S3" />';

		} catch (AwsException $e) {
			//echo "Error obteniendo la imagen: " . $e->getMessage();
		}
	}

	public function obtenerArchivo($url)
	{

		// Configura el cliente de S3 usando las credenciales por defecto (IAM Role, EC2, Lambda)
		$s3Client = new S3Client([
			'version' => 'latest',
			'region'  => 'us-east-1',  // Cambia a tu región
		]);

		// Nombre del bucket y la clave del archivo en S3
		$bucketName = 'kt2-images';
		$keyName = $url; // Nombre del archivo en S3
		$expiration = '+10 minutes'; // Duración de la URL prefirmada

		try {
		
			$command = $s3Client->getCommand('GetObject', [
				'Bucket' => $bucketName,
				'Key'    => $keyName
			]);

			return (string) $s3Client->createPresignedRequest($command, $expiration)->getUri();

		} catch (AwsException $e) {
			//echo "Error obteniendo la imagen: " . $e->getMessage();
		}
	}

	public function padreHijo($data, $item, $id, $id_padre)
	{


		$item++;
		foreach ($data as $clave => $row) {

			//$blobFile	= $row['image'];
			//$file		= $id . ".jpg";
			$url 		= date("Y") . "/" . date("m") . "/" . $row['url'];



			//if ($blobFile != '') $this->cargarIMG($blobFile, $url);

			$sql = "INSERT INTO procedimiento_detalle (id_procedimiento,titulo,datos,imagen,nivel,id_padre) 
			VALUE ('{$id}','{$row['title']}','{$row['description']}','{$url}','{$item}','{$id_padre}');";

			$exe = $this->db->statement($sql);
			if (count($row['children']) > 0) {
				$this->padreHijo($row['children'], $item, $id, $exe->insert_id);
			} else {
				continue;
			}
		}
	}

	public function cargarProcedimiento($data)
	{

		$sql = "INSERT INTO procedimientos (nombre,descripcion,fecha_carga) VALUE ('{$data->titulo[0]['title']}','{$data->titulo[0]['description']}',now())";
		$exe = $this->db->statement($sql);
		if (count($data->tree) > 0) {
			$this->padreHijo($data->tree, 0, $exe->insert_id, 0);
		}
		return $exe;
	}

	public function listarProcedimientos($data)
	{
		$sql = "SELECT * FROM procedimientos WHERE activo = 1";
		$params = [];
		if (!empty($data->pais)) {
			$sql .= " AND pais = ?";
			$params[] = $data->pais;
		}
		return $this->db->select($sql, $params);
	}

	public function grabarSatisfaccion($datos)
	{
		$fueUtil 	=  $datos->util;
		$id 	 	=  $datos->id;
		$usuario 	=  Session::user()->username;

		$query = "INSERT INTO procedimiento_encuesta(idProcedimiento,usuario,util,fecha)
                  VALUES(:idProcedimiento,:usuario,:fueUtil,NOW())";


		$res  = $this->db->statement($query, array(
			":idProcedimiento" => $id,
			":usuario" => $usuario,
			":fueUtil" => $fueUtil
		));

		return $res;
	}

	public function searchProcedimiento($data)
	{

		$sql = "SELECT 
				procedimientos.id,
				procedimiento_detalle.id as id_hijo,
				procedimiento_detalle.titulo,
				procedimiento_detalle.imagen,
				procedimiento_detalle.nivel,
				procedimiento_detalle.id_padre,
				procedimiento_detalle.datos
				FROM procedimientos
				LEFT JOIN `procedimiento_detalle` ON procedimientos.id= procedimiento_detalle.id_procedimiento
				WHERE procedimientos.activo=1 and procedimiento_detalle.id is not null AND procedimientos.id = {$data->data}
				ORDER by nivel asc,id_padre asc";
		$res = $this->db->select($sql);

		$modulos = array();
		foreach ($res->data as $row) {
			$padre[$row["id_hijo"]] = $row["id_padre"];
			if ($row["nivel"] == 1) {
				$item2 = 0;
				$modulos[$row["id_hijo"]]["id"] = $row["id_hijo"];
				$modulos[$row["id_hijo"]]["nivel"] = $row["nivel"];
				$modulos[$row["id_hijo"]]["id_padre"] = $row["id_padre"];
				$modulos[$row["id_hijo"]]["titulo"] = $row["titulo"];
				$modulos[$row["id_hijo"]]["datos"] = $row["datos"];
				$modulos[$row["id_hijo"]]["imagen"] = $this->obtenerIMG($row["imagen"]);
			}

			if ($row["nivel"] == 2) {

				$item3 = 0;
				$modulos[$row["id_padre"]]["children"][$item2]["id_hijo"] = $row["id_hijo"];
				$modulos[$row["id_padre"]]["children"][$item2]["nivel"] = $row["nivel"];
				$modulos[$row["id_padre"]]["children"][$item2]["id_padre"] = $row["id_padre"];
				$modulos[$row["id_padre"]]["children"][$item2]["titulo"] = $row["titulo"];
				$modulos[$row["id_padre"]]["children"][$item2]["datos"] = $row["datos"];
				$modulos[$row["id_padre"]]["children"][$item2]["imagen"] = $this->obtenerIMG($row["imagen"]);
				$nivel2[$row["id_hijo"]] = $item2;
				$item2++;
			}

			if ($row["nivel"] == 3) {
				$id_padre = $padre[$row["id_padre"]];

				$modulos[$id_padre]["children"][$nivel2[$row["id_padre"]]]["children"][$item3]["id_hijo"] = $row["id_hijo"];
				$modulos[$id_padre]["children"][$nivel2[$row["id_padre"]]]["children"][$item3]["nivel"] = $row["nivel"];
				$modulos[$id_padre]["children"][$nivel2[$row["id_padre"]]]["children"][$item3]["id_padre"] = $row["id_padre"];
				$modulos[$id_padre]["children"][$nivel2[$row["id_padre"]]]["children"][$item3]["titulo"] = $row["titulo"];
				$modulos[$id_padre]["children"][$nivel2[$row["id_padre"]]]["children"][$item3]["datos"] = $row["datos"];
				$modulos[$id_padre]["children"][$nivel2[$row["id_padre"]]]["children"][$item3]["imagen"] = $this->obtenerIMG($row["imagen"]);
				$item3++;
			}
			/*
				if($row["nivel"]==2){
				$modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["id"] = $row["submenu_id"];
				$modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["nombre"] = $row["submenu_nombre"];
				$modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["nivel"] = $row["submenu_nivel"];
				$modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["padre"] = $row["menu_id"];
				$modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["estado_desarrollo"] = $row["estado_desarrollo"];
				$modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["checked"] = false;*/
		}


		// if($toArray) $modulos = $this->toArray($modulos);
		$modulos = array_values($modulos);
		$res->data = $modulos;

		return $res;
	}



	public function dynamicUploadService($data)
	{
		// Directorio de subida de archivos
		//$uploadDir = "uploads/";

		//if ($_SERVER["REQUEST_METHOD"] === "POST") {
		//$titles = $_POST['titles']; // Array de títulos
		$titles = $data->titles; // Array de títulos
		$files = $_FILES['files'];  // Grupo de archivos organizados por índice de grupo

		$response = ["success" => true, "message" => [], "failed" => []];
		//$sql = "INSERT INTO procedimientos (nombre,descripcion,fecha_carga) VALUE ('sssss','',now())";
		//$sql = "INSERT INTO procedimientos (nombre,descripcion,fecha_carga) VALUE ('{$data->titulo[0]['title']}','{$data->titulo[0]['description']}',now())";
		$id = 0;
		if (($data->id ?? 0) > 0) {
			$sql = "UPDATE procedimientos set nombre = :nombre, descripcion= :descripcion WHERE id=:id";
			$exe = $this->db->statement($sql, [
				":nombre" => $data->title ?? '',
				":descripcion" => $data->description ?? '',
				":id" => $data->id,
			]);
			$id = $data->id;

			ListenerProcedimentos::listener(Session::user()->username, date("Y-m-d H:i:s"), $id, "create");
		} else {
			$sql = "INSERT INTO procedimientos (nombre,descripcion,fecha_carga,pais) VALUE ('{$data->title}','{$data->description}',now(),'{$data->pais}')";
			$exe = $this->db->statement($sql);
			$id = $exe->insert_id;

			ListenerProcedimentos::listener(Session::user()->username, date("Y-m-d H:i:s"), $id, "update");
		}
		
		// Iterar sobre los grupos
		foreach ($titles as $groupIndex => $title) {
			if (!empty($title)) {
				// Verificar si hay archivos en este grupo
				if (!empty($files['name'][$groupIndex])) {
					foreach ($files['name'][$groupIndex] as $fileIndex => $fileName) {

						$filename = $files['name'][$groupIndex][$fileIndex];
						$filename = str_replace("'", "", $fileName);

						$url = date("Y") . "/" . date("m") . "/" . date("YmdHis") . "_" . $filename;

						$title = str_replace("'", "", $title);

						$sql = "INSERT INTO procedimiento_detalle (id_procedimiento,titulo,datos,imagen,nivel,id_padre) VALUE ('{$id}','{$title}','','{$url}','','');";

						$this->db->statement($sql);

						$this->cargarArchivoS3($files['tmp_name'][$groupIndex][$fileIndex], $files['type'][$groupIndex][$fileIndex], $url);
					}
				} else {
					$response["failed"][] = "No se subieron archivos en el grupo {$groupIndex}.";
					$response["success"] = false;
				}
			} else {
				$response["failed"][] = "Falta el título para el grupo {$groupIndex}.";
				$response["success"] = false;
			}
		}

		// Enviar la respuesta en formato JSON
		//return json_encode($response);
		return $exe;
		//}
	}

	public function cargarArchivoS3($fileTMP, $fileType, $url)
	{
		// Configura el cliente de S3 usando las credenciales por defecto (IAM Role, EC2, Lambda)
		$s3Client = new S3Client([
			'version' => 'latest',
			'region'  => 'us-east-1',  // Cambia a tu región
		]);

		// Datos del blob
		$bucketName = 'kt2-images';
		//$keyName = $file; //'archivo.jpg'; // Nombre del archivo en S3
		//$blob = $this->tratarImg($blobFile); //file_get_contents('php://input'); // Si estas recibiendo el blob desde una petici�n

		try {
			// Subir el archivo a S3
			$result = $s3Client->putObject([
				'Bucket' => $bucketName,
				'Key'    => $url,
				'Body' => file_get_contents($fileTMP),
				'ContentType' => $fileType
				//'Body'   => $blob,
				//'ContentType' => 'image/jpeg', // Ajusta el tipo de contenido según el archivo
				//'ACL'    => 'public-read', // Si quieres que el archivo sea accesible pblicamente
			]);

			//echo "Archivo subido exitosamente. URL: " . $result['ObjectURL'];
		} catch (AwsException $e) {
			//echo "Error subiendo archivo: " . $e->getMessage();
		}
	}

	public function searchProcedimientoFilesDev($data)
	{

		$sql = "SELECT 
				procedimientos.id,
				procedimiento_detalle.id as id_hijo,
				procedimiento_detalle.titulo,
				procedimiento_detalle.imagen,
				procedimiento_detalle.nivel,
				procedimiento_detalle.id_padre,
				procedimiento_detalle.datos
				FROM procedimientos
				LEFT JOIN `procedimiento_detalle` ON procedimientos.id= procedimiento_detalle.id_procedimiento
				WHERE procedimientos.activo=1 and procedimiento_detalle.id is not null AND procedimientos.id = {$data->data}
				ORDER by nivel asc,id_padre asc";
		$res = $this->db->select($sql);

		$modulos = array();
		foreach ($res->data as $row) {



			$modulos[$row["id_hijo"]]["id"] = $row["id_hijo"];
			$modulos[$row["id_hijo"]]["nivel"] = $row["nivel"];
			$modulos[$row["id_hijo"]]["id_padre"] = $row["id_padre"];
			$modulos[$row["id_hijo"]]["titulo"] = $row["titulo"];
			$modulos[$row["id_hijo"]]["datos"] = $row["datos"];
			$modulos[$row["id_hijo"]]["imagen"] = $this->obtenerArchivo($row["imagen"]);
		}


		// if($toArray) $modulos = $this->toArray($modulos);
		$modulos = array_values($modulos);
		$res->data = $modulos;

		return $res;
	}

	public function searchProcedimientoFiles($request)
	{
		$modulos = array();
		$id = $request->id;
		$sql_main = "SELECT * FROM {$this->table_procedimientos} WHERE id = :id";

		$data = $this->db->find($sql_main, array(':id' => $id))->data;

		$sql = "SELECT
				procedimientos.id,
				procedimiento_detalle.id AS id_hijo,
				procedimiento_detalle.titulo,
				procedimiento_detalle.imagen,
				procedimiento_detalle.imagen AS ruta_relativa,
				procedimiento_detalle.nivel,
				procedimiento_detalle.id_procedimiento AS idParent,
				procedimiento_detalle.datos
			FROM {$this->table_procedimientos}
			LEFT JOIN {$this->table_procedimientos_detalle} ON procedimientos.id = procedimiento_detalle.id_procedimiento
			WHERE procedimientos.activo = 1 AND procedimiento_detalle.activo = 1
			AND procedimiento_detalle.id IS NOT NULL AND procedimientos.id = :id
			ORDER BY nivel ASC, id_padre ASC
		";

		$res = $this->db->select($sql, array(':id' => $id));

		foreach ($res->data as $row) {
			$modulos[$row["id_hijo"]]["id"] = $row["id_hijo"];
			$modulos[$row["id_hijo"]]["nivel"] = $row["nivel"];
			$modulos[$row["id_hijo"]]["id_padre"] = $row["idParent"];
			$modulos[$row["id_hijo"]]["titulo"] = $row["titulo"];
			$modulos[$row["id_hijo"]]["datos"] = $row["datos"];
			$modulos[$row["id_hijo"]]["ruta_relativa"] = $row["ruta_relativa"];
			$modulos[$row["id_hijo"]]["imagen"] = $this->obtenerArchivo($row["imagen"]);
			// $modulos[$row["id_hijo"]]["imagen"] = "";
		}

		$modulos = array_values($modulos);

		$data["archivos"] = $modulos;

		return array(
			'status' => true,
			'data' => $data,
		);
	}

	public function saveItem($request)
	{
		$id = $request->id;
		$title = $request->title;
		$description = $request->description;

		$sql = "UPDATE {$this->table_procedimientos} SET nombre = :title, descripcion = :description WHERE id = :id";

		$result = $this->db->statement($sql, array(
			':id' => $id,
			':title' => $title,
			':description' => $description
		));

		// CALL LISTENER NOTIFICATIONS
		ListenerProcedimentos::listener(Session::user()->username, date("Y-m-d H:i:s"), $id, "update");

		return array(
			'status' => true
		);
	}

	public function deleteItem($request)
	{
		$id = $request->id;

		$sql = "
			UPDATE {$this->table_procedimientos}
				SET activo = 0
			WHERE id = :id
		";

		$result = $this->db->statement($sql, array(
			':id' => $id
		));

		return array(
			'status' => true
		);
	}


	public function deleteSubItem($request)
	{
		$id = $request->id;

		$sql = "UPDATE {$this->table_procedimientos_detalle} SET activo = 0 WHERE id = :id";

		$result = $this->db->statement($sql, array(
			':id' => $id
		));

		return array(
			'status' => true
		);
	}

	public function buscarProcedimientoList($data)
	{
		$sql = "SELECT * FROM procedimientos WHERE  id = '{$data->data}' or nombre like '%{$data->data}%'";
		$res = $this->db->select($sql);
		return $res;
	}

	public function getCalification($request)
	{
		$id = $request->id;

		$sql = "SELECT sum(IF(util = 'SI', 1, 0)) AS cantidad_si, sum(IF(util = 'NO', 1, 0)) AS cantidad_no FROM {$this->table_procedimientos_encuesta} WHERE idProcedimiento = :id";

		$result = $this->db->find($sql, array(':id' => $id));

		return array(
			'status' => true,
			'data' => $result->data
		);
	}

	public function saveCalification($request)
	{
		$id = $request->id;
		$value = $request->value;
		$user = Session::user()->username;

		// VERIFY LIKE
		$sql_find = "
			SELECT 
				id
			FROM {$this->table_procedimientos_encuesta}
			WHERE usuario = :usuario AND util = :util AND idProcedimiento = :id
		";

		$result_find = $this->db->find($sql_find, array(
			':id' => $id,
			':usuario' => $user,
			':util' => $value
		));

		if (!$result_find->data["id"]) {
			$sql_delete = "
				DELETE FROM {$this->table_procedimientos_encuesta}
				WHERE usuario = :usuario  AND idProcedimiento = :id
			";

			$result_delete = $this->db->statement($sql_delete, array(
				':id' => $id,
				':usuario' => $user
			));

			$sql = "
				INSERT INTO {$this->table_procedimientos_encuesta} (idProcedimiento, usuario, util, fecha)
				VALUES (:id, :user, :util, NOW())
			";

			$result = $this->db->statement($sql, array(
				':id' => $id,
				':user' => $user,
				':util' => $value
			));
		}

		return array('status' => true, 'msg' => "repetido");
	}

	public function saveFile($request)
	{
		try {
			$id = $request->id;
			$title = $request->title;
			$type = $request->type;
			$file = isset($_FILES["file"]) ? $_FILES["file"] : null;
			$parentId = $request->parentId ?? null;


			// SAVE
			if ($type == "save" && $file != null) {
				// INSERTAR EN TABLA

				$filename = $file["name"];
				$url = date("Y/m") . "/" . date("YmdHis") . "_" . $filename;

				$sql = "
					INSERT INTO {$this->table_procedimientos_detalle} (id_procedimiento, titulo, datos, imagen, nivel, id_padre)
					VALUES (:id, :title, :datos, :imagen, :nivel, :idPadre)
				";

				$result = $this->db->statement($sql, array(
					':id' => $id,
					':title' => $title,
					':datos' => "",
					':imagen' => $url,
					':nivel' => "",
					':idPadre' => "",
				));

				// CALL LISTENER EVENTS NOTIFICATIONS0
				ListenerProcedimentos::listener(Session::user()->username, date("Y-m-d H:i:s"), $id, "create");

				// GUARDAR EN S3
				$this->cargarArchivoS3($file['tmp_name'], $file['type'], $url);
			} else if ($type == "update") {
				// ACTUALIZAR
				$filter = "";

				$params = array(
					':id' => $id,
					':title' => $title,
				);

				if ($file != null) {
					$filter = " , imagen = :url ";

					$filename = $file["name"];
					$url = date("Y/m") . "/" . date("YmdHis") . "_" . $filename;

					$params[":url"] = $url;
				}

				$sql_update = "
					UPDATE {$this->table_procedimientos_detalle}
						SET titulo = :title {$filter}
					WHERE id = :id
				";

				$result_update = $this->db->statement($sql_update, $params);

				// CALL LISTENER EVENTS NOTIFICATIONS
				ListenerProcedimentos::listener(Session::user()->username, date("Y-m-d H:i:s"), $parentId, "update");

				// GUARDAR EN S3
				if ($file != null) $this->cargarArchivoS3($file['tmp_name'], $file['type'], $url);
			}

			return array(
				'status' => true,
				'request' => $request->all(),
				'files' => $_FILES["file"]["name"]
			);
		} catch (\Exception $e) {
			return array(
				'status' => false,
				'data' => array()
			);
		}
	}

	public function searchProcedemiento($request)
	{
		$id = $request->value;

		$sql = "
			SELECT
				* 
			FROM {$this->table_procedimientos}
			WHERE activo = 1 AND id = :id
		";

		$result = $this->db->select($sql, array(
			':id' => $id
		));

		return $result;
	}
}
