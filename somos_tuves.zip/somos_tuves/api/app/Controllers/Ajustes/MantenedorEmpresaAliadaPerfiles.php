<?php

namespace App\Controllers\Ajustes;

use App\Controllers\Controller;
use App\Models\Ajustes\GestorUsuarioModel;
use App\Models\DB;
use App\Models\Session;
use App\Utils\Password;
use App\Utils\Util;

class MantenedorEmpresaAliadaPerfiles extends Controller{
    private $db;
    private $model;
    private $table_empresas;
    private $table_perfiles;
    
    public function __construct() {
        $this->db = new DB();
        $this->table_empresas = "t2_empresas_aliadas";
        $this->table_perfiles = "perfiles";
    }

    public function index() {
        $query = "
            SELECT
            *
            FROM {$this->table_empresas}
        ";

        $result = $this->db->select($query);

        return $result;
    }

    public function store($request) {
        $nombre = $request->nombre;

        $fields = array(
            'nombre_empresa' => $nombre,
            'activo' => 1
        );

        $result = $this->db->statementInsert($this->table_empresas, $fields);

        return array(
            'status' => true,
            'data' => $result
        );
    }

    public function update($request) {
        $nombre = $request->nombre;
        $state = $request->state ? 1 : 0;
        $id = $request->id;

        $fields = array(
            'nombre_empresa' => $nombre,
            'activo' => $state
        );

        $result = $this->db->statementUpdate($this->table_empresas, $fields, array(
            'id' => $id
        ));

        return $result;
    }

    public function destroy($request) {
        $id = $request->id;

        $query = "
            DELETE FROM t2_empresas_aliadas WHERE id = '$id'
        ";

        $result = $this->db->statement($query);

        $result->sql = $query;

        return $result;
    }

    ## PERFILES

    public function init_perfiles() {
        $query = "
            SELECT
            *
            FROM {$this->table_perfiles}
        ";

        $result = $this->db->select($query);

        return $result;
    }

    public function perfilesStore($request) {
        $nombre = $request->nombre;

        $fields = array(
            'nombre' => $nombre,
            'estado' => 1
        );

        $result = $this->db->statementInsert($this->table_perfiles, $fields);

        return $result;
    }

    
    public function perfilesUpdate($request) {
        $nombre = $request->nombre;
        $estado = $request->activo ? 1 : 0;
        $id = $request->id;

        $fields = array(
            'nombre' => $nombre,
            'estado' => $estado
        );

        $result = $this->db->statementUpdate($this->table_perfiles, $fields, array(
            'id' => $id
        ));

        return $result;
    }

    public function perfilesDestroy($request) {
        $id = $request->id;

        $query = "
            DELETE FROM perfiles WHERE id = '$id'
        ";

        $result = $this->db->statement($query);

        return $result;
    }


}
