<?php

namespace App\Controllers\Ajustes;

use App\Controllers\Controller;
use App\Models\DB;

class EstadoDesarrolloModulosController extends Controller {
    private $db;

    public function __construct() {
        $this->middleware();
        $this->db = new DB();
    }

    public function index() {
        $sql = "
            SELECT
                m2.id as id,
                m2.nombre as NOMBRE,
                CONCAT(m1.ruta, '/', m2.ruta) AS RUTA_REACT,
                (SELECT s.links FROM sub_menu s WHERE s.nombre = m2.nombre AND s.estado = 1 LIMIT 1) AS RUTA_PHP,
                (SELECT s.contador FROM sub_menu s WHERE s.nombre = m2.nombre AND s.estado = 1 LIMIT 1) AS CONTADOR,
                log.desarrollador,
                (SELECT concat(u.nombre_tec, ' ', u.ape_tec) FROM user_tec u WHERE u.`user` = log.desarrollador AND u.`user` != '' LIMIT 1) as FULLNAME_DEV,
                log.fecha_inicio_dev,
                log.fecha_fin_dev,
                log.fecha_real_dev,
                log.fecha_inicio_validacion,
                log.fecha_fin_validacion,
                m2.estado_desarrollo AS ESTADO_DESARROLLO
            FROM
                t2_menu m1
            INNER JOIN t2_menu m2 ON m1.id = m2.menu_id_padre
            LEFT JOIN log_modulos_desarrollo log ON log.t2_menu_id = m2.id
            ORDER BY CONTADOR DESC
        ";


        $result = $this->db->select($sql);

        return array(
            'status' => true,
            'data' => array(
                'modules' => $result->data
            )
        );
    }

    public function developers() {
        $sql_dev = "
            SELECT
                user,
                CONCAT(nombre_tec, ' ', ape_tec) AS fullname
            FROM user_tec WHERE user IN ('gfarfan', 'hmayhuay', 'agamonal')
        ";

        $result_dev = $this->db->select($sql_dev);

        return $result_dev;
    }

    public function updateModule($request) {
        $id = $request->id;
        $estado = $request->estado;
        $desarrollador = $request->desarrollador;
        $fecha_inicio_dev = $request->fecha_inicio_dev;
        $fecha_fin_dev = $request->fecha_fin_dev;
        $fecha_real_dev = $request->fecha_real_dev;
        $fecha_inicio_validacion = $request->fecha_inicio_validacion;
        $fecha_fin_validacion = $request->fecha_fin_validacion;
        $is_developer = $request->is_developer;

        $sql_t2_menu = "";
        
        $sql = "";
        $result = array();
        $params = array();
        
        $sql_find = "";
        $params_find = array();

        $sql_find = "
            SELECT * FROM log_modulos_desarrollo WHERE t2_menu_id = :id
        ";

        $params_find = array(
            ':id' => $id
        );

        $result_find = $this->db->find($sql_find, $params_find);

        if(count($result_find->data) > 0) {
            if($is_developer ){
                $sql = "
                    UPDATE log_modulos_desarrollo
                    SET 
                    desarrollador = :desarrollador,
                    fecha_inicio_dev = :fecha_inicio_dev,
                    fecha_fin_dev = :fecha_fin_dev,
                    fecha_real_dev = :fecha_real_dev,
                    fecha_inicio_validacion = :fecha_inicio_validacion,
                    fecha_fin_validacion = :fecha_fin_validacion
                    WHERE t2_menu_id = :id
                ";

                $params = array(
                    ':desarrollador' => $desarrollador,
                    ':fecha_inicio_dev' => $fecha_inicio_dev,
                    ':fecha_fin_dev' => $fecha_fin_dev,
                    ':fecha_real_dev' => $fecha_real_dev,
                    ':fecha_inicio_validacion' => $fecha_inicio_validacion,
                    ':fecha_fin_validacion' => $fecha_fin_validacion,
                    ':id' => $id
                );

            } else {
                $sql = "
                    UPDATE log_modulos_desarrollo
                    SET 
                    fecha_inicio_validacion = :fecha_inicio_validacion,
                    fecha_fin_validacion = :fecha_fin_validacion
                    WHERE t2_menu_id = :id
                ";

                $params = array(
                    ':fecha_inicio_validacion' => $fecha_inicio_validacion,
                    ':fecha_fin_validacion' => $fecha_fin_validacion,
                    ':id' => $id
                );
            }

        } else {
            $sql = "
                INSERT INTO log_modulos_desarrollo 
                (
                    t2_menu_id,
                    desarrollador,
                    fecha_inicio_dev,
                    fecha_fin_dev,
                    fecha_real_dev,
                    fecha_inicio_validacion,
                    fecha_fin_validacion
                )
                VALUES 
                (
                    :id,
                    :desarrollador,
                    :fecha_inicio_dev,
                    :fecha_fin_dev,
                    :fecha_real_dev,
                    :fecha_inicio_validacion,
                    :fecha_fin_validacion      
                )
            ";

            $params = array(
                ':id' => $id,
                ':desarrollador' => $desarrollador,
                ':fecha_inicio_dev' => $fecha_inicio_dev,
                ':fecha_fin_dev' => $fecha_fin_dev,
                ':fecha_real_dev' => $fecha_real_dev,
                ':fecha_inicio_validacion' => $fecha_inicio_validacion,
                ':fecha_fin_validacion' => $fecha_fin_validacion
            );
        }

        /* UPDATE T2 MENU ESTADO */
        $sql_t2_menu = "
            UPDATE t2_menu
            SET estado_desarrollo = :estado
            WHERE id = :id
        ";
        
        $param_t2_menu = array(
            ':id' => $id,
            ':estado' => $estado
        );

        $result_t2_menu = $this->db->statement($sql_t2_menu, $param_t2_menu);

        $result = $this->db->statement($sql, $params);

        return array(
            'status' => true,
            'data' => array(
                'update_menu_estado' => $result_t2_menu,
                'update_log_modulos' => $result,
                'log_modules' => $result_find
            ),
            'queries' => array(
                'sql_update_menu_estado' => $sql_t2_menu,
                'sql_update_log_modulos' => $sql,
                'sql_log_modules' => $sql_find
            ),
            'request' => $request->all()
        );
    }
}