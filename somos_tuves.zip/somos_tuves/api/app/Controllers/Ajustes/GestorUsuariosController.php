<?php

namespace App\Controllers\Ajustes;

use App\Controllers\Controller;
use App\Models\Ajustes\GestorUsuarioModel;
use App\Models\DB;
use App\Models\Session;
use App\Utils\Password;
use App\Utils\Util;
use App\Models\Ajustes\PermisosKT2Model;

class GestorUsuariosController extends Controller
{

    private $db;
    private $model;
    private $table_perfiles;
    private $modelPermisos;
    private $table_users;
    private $table_acceso_usuarios;
    private $table_perfiles_permisos;

    public function __construct()
    {
        $this->middleware();
        $this->db = new DB();
        $this->table_perfiles = "perfiles";
        $this->table_perfiles_permisos = "perfiles_permisos";
        $this->table_acceso_usuarios = "t2_acceso_usuario";
        $this->table_users = "user_tec";
        $this->model = new GestorUsuarioModel();
        $this->modelPermisos = new PermisosKT2Model();
    }

    public function listarUsuarios($request)
    {

        $filters = "";
        $params = array();
        if ($request->eliminado) {
            $filters .= " AND u.activo = -1";
        } else {
            if (!!$request->estado) {
                $filters .= " AND u.activo = :estado";
                $estados = array(
                    "Activo" => "1",
                    "Inactivo" => "0",
                    "Eliminados" => "-1",
                );
                $params[":estado"] = $estados[$request->estado];
            }
        }

        if (!!$request->usuario) {
            $filters .= " AND u.user = :usuario";
            $params[":usuario"] = $request->usuario;
        }
        if (!!$request->rut) {
            $filters .= " AND u.rut_tecnico = :rut";
            $params[":rut"] = $request->rut;
        }
        if (!!$request->tipo_ejecutivo) {
            $filters .= " AND u.tipo_ejecutivo = :tipo_ejecutivo";
            $params[":tipo_ejecutivo"] = $request->tipo_ejecutivo;
        }
        if (!!$request->perfil) {
            $filters .= " AND p.nombre = :perfil";
            $params[":perfil"] = $request->perfil;
        }
        if (!!$request->empresa_aliada) {
            $filters .= " AND u.empresa_aliada = :empresa_aliada";
            $params[":empresa_aliada"] = $request->empresa_aliada;
        }


        $query = "SELECT 
                    nombre_tec nombres,
                    ape_tec apellidos,
                    REPLACE(`user`, '\t', '') usuario,
                    REPLACE(rut_tecnico, '\t', '') rut,
                    tipo_user perfil,
                    p.nombre perfil_nombre,
                    tipo_ejecutivo,
					u.fecha_ultima_visita,
					u.rut_creacion as usuario_creador,
                    empresa_aliada,
					(SELECT CONCAT(nombre_tec, ' ', ape_tec) FROM user_tec ut where ut.rut_tecnico = u.rut_creacion) as nombre_creador,
                    DATE_FORMAT(fecha_creacion,'%d/%m/%Y %H:%i:%s') fecha_ingreso,
                    activo estado,
                    (CASE
                        WHEN activo = 1 THEN 'Activo'
                        WHEN activo = 0 THEN 'Inactivo'
                        WHEN activo = -1 THEN 'Eliminado'
                        ELSE 0
                    END) estado_label,
                    activo estado
                    FROM user_tec u
                    INNER JOIN perfiles p ON u.tipo_user = p.id
                    WHERE 1 {$filters}
                    -- AND user = 'gfarfantest'
                    ORDER BY fecha_creacion DESC";

        $res = $this->db->select($query, $params);
        $data = array();
        foreach ($res->data as $key => $row) {
            if ($row["estado"] == "0") {

                $queryInactivo = "SELECT id,fecha_ejecucion,comentario FROM `cronjobs` WHERE comentario LIKE :usuario AND ejecutado = 0 AND fecha_ejecucion >= NOW()";
                $programado = $this->db->find($queryInactivo, array(
                    ":usuario" => "%" . $row["usuario"] . "%",
                ))->data;
                if (!!$programado["id"]) {
                    //echo __LINE__;
                    $row["programar"] = true;
                    $row["fecha_programacion"] = $programado["fecha_ejecucion"];
                }
            }
            $data[] = $row;
        }
        $res->sql = $query;
        $res->data = $data;
        return $res;
    }

    public function verificarDisponibiladUsuario($request)
    {
        $query = "SELECT user, rut_tecnico, activo FROM user_tec WHERE rut_tecnico = :rut OR user = :usuario";

        $res = $this->db->find($query, array(":rut" => $request->value, ":usuario" => $request->value));
        $res->data["disponible"] = true;
        $res->data["message"] = "Usuario correcto";
        $res->data["icon"] = "check";
        $res->data["color"] = "success";
        if (!!($res->data["user"] ?? '')) {
            $res->data["disponible"] = false;
            if ($res->data["activo"] == "-1") {
                $res->data["message"] = "El usuario se encuentra eliminado";
                $res->data["icon"] = "warning";
                $res->data["color"] = "warning";
            } else {
                $tipo = ($res->data['rut_tecnico'] ?? '') == $request->value ? 'Rut' : 'usuario';
                $res->data["message"] = "El $tipo ya existe ";
                $res->data["icon"] = "ban";
                $res->data["color"] = "danger";
            }
        }
        return $res;
    }
    public function crearUsuario($request)
    {
        // $this->displayErrors();
        if (!$request->password) {
            $password = Password::generate();
            $request->password = $password->password;
        }
        $params = array(
            "nombre_tec" => strtoupper(Util::replaceSpecialCharactersFull($request->nombres)),
            "ape_tec" => strtoupper(Util::replaceSpecialCharactersFull($request->apellidos)),
            "rut_tecnico" => $request->rut,
            "user" => $request->usuario,
            "pass" => Password::hash($request->password),
            "tipo_user" => $request->perfil,/*
            "empresa_aliada" => $request->empresa_aliada,
            "tipo_ejecutivo" => $request->tipo_ejecutivo,*/
            "fecha_creacion" => date("Y-m-d H:i:s"),
            "rut_creacion" => Session::user()->dni,
        );

        $res =  $this->db->statementInsert('user_tec', $params);
        $query = "SELECT user,
					nombre_tec nombre,
					ape_tec apellido,
					user usuario,
					p.nombre perfil,
					empresa_aliada aliado
					FROM user_tec u 
					INNER JOIN perfiles p ON u.tipo_user = p.id
					WHERE user = :user";

        $usuario = $this->db->find($query, array(
            "user" => $request->usuario,
        ));
        $usuario->data["password"] = $request->password;

        if ($request->usuario_modelo_check) {
            $this->model->permisosPorUsuarioModel(array($request->usuario), $request->usuario_modelo);
        } else if (($request->perfil ?? 0) > 0) {
            //usara los permisos del perfil seleccionado
            $this->model->colocarPermisosXRol([$request->usuario], (int)$request->perfil);
        }

        //ESTO YA SE INSERTA CUANDO LLAMAS AL METODO adicionarPermisos() O asignarPermisos() que esta en $this->model->permisosPorUsuarioModel
        /*$queryLog = "INSERT INTO t2_acceso_usuario_log(usuario,usuario_accion,accion,fecha_registro)
                    VALUES(:usuario,:usuario_sesion,:accion,NOW())";
        $this->db->statement($queryLog, array(
            ":usuario" => $request->usuario,
            ":usuario_sesion" => Session::user()->username,
            ":accion" => "CREACION USUARIO",
        ));*/
        return $usuario;
    }
    public function editarUsuario($request)
    {
        // return $request->all();
        $params = array(
            "nombre_tec" => $request->nombres,
            "ape_tec" => $request->apellidos,
            "rut_tecnico" => $request->rut,
            "tipo_user" => $request->perfil,
            "empresa_aliada" => $request->empresa_aliada,
            "tipo_ejecutivo" => $request->tipo_ejecutivo,
            "activo" => $request->estado,
        );
        $where = array(
            "user" => $request->usuario,
        );
        $resp = $this->db->statementUpdate("user_tec", $params, $where);
        if (!$resp->status) {
            return array(
                "status" => false,
                "message" => "Erro al actualizar"
            );
        }


        if ($params["activo"] == "0" && $request->programar) {
            $resp->message = "Se programara";

            $params = array(
                "fecha_registro" => date("Y-m-d H:i:s"),
                "usuario_registro" => Session::user()->username,
                "class" => "App\Commands\ProgramadorEstado",
                "fecha_ejecucion" => $request->fecha_programacion,
                "comentario" => $request->usuario,
                "ejecutado" => "0",
            );
            $this->db->statementInsert("t2_web_extranet.cronjobs", $params);
            return $resp;
        }

        $queryLog = "INSERT INTO t2_acceso_usuario_log(usuario,usuario_accion,accion,fecha_registro) VALUES(:usuario,:usuario_sesion,:accion,NOW())";
        $this->db->statement($queryLog, array(
            ":usuario" => $request->usuario,
            ":usuario_sesion" => Session::user()->username,
            ":accion" => "EDITAR USUARIO",
        ));
        return $resp;
    }
    public function resetearPassword($request)
    {
        $passGenerate = Password::generate();
        $params = array(
            "pass" => $passGenerate->hash,
        );
        $where = array(
            "user" => $request->user,
        );
        $res = $this->db->statementUpdate("user_tec", $params, $where);
        $res->data["password"] = $passGenerate->password;

        $queryLog = "INSERT INTO t2_acceso_usuario_log(usuario,usuario_accion,accion,fecha_registro)
                    VALUES(:usuario,:usuario_sesion,:accion,NOW())";
        $this->db->statement($queryLog, array(
            ":usuario" => $request->user,
            ":usuario_sesion" => Session::user()->username,
            ":accion" => "RESETEAR USUARIO",
        ));
        return $res;
    }
    public function desactivarUsuario($request)
    {
        $params = array(
            "activo" => $request->estado,
        );
        if ($request->estado == 0) {
            $params["fecha_eliminacion"] = date("Y-m-d H:i:s");
        }
        $where = array(
            "user" => $request->user,
        );

        $queryLog = "INSERT INTO t2_acceso_usuario_log(usuario,usuario_accion,accion,fecha_registro)
                    VALUES(:usuario,:usuario_sesion,:accion,NOW())";
        $this->db->statement($queryLog, array(
            ":usuario" => $request->user,
            ":usuario_sesion" => Session::user()->username,
            ":accion" => ($request->estado == "1" ? "ACTIVAR" : "DESACTIVAR") . " USUARIO",
        ));
        return $this->db->statementUpdate("user_tec", $params, $where);
    }

    public function exportarUsuarios($request)
    {
        $res = $this->listarUsuarios($request);

        $heads = array(
            "usuario" => "USUARIO",
            "rut" => "RUT",
            "nombres" => "NOMBRE",
            "apellidos" => "APELLIDO",
            "perfil_nombre" => "PERFIL",
            "tipo_ejecutivo" => "TIPO EJECUTIVO",
            "empresa_aliada" => "EMPRESA ALIADA",
            "estado_label" => "ESTADO",
            "fecha_programacion" => "FECHA REACTIVACION",
            "fecha_ultima_visita" => "ULTIMA CONEXION",
            "fecha_ingreso" => "FECHA CREACION",
            "usuario_creador" => "USUARIO CREADOR",
            "nombre_creador" => "NOMBRE CREADOR",
        );


        // return "hola";
        return $this->view("Ajustes/tabla_usuarios", array(
            "usuarios" => $res->data,
            "heads" => $heads,
        ));
    }

    public function validarUsuariosExcel($request)
    {
        $archivo = $_FILES['excel-usuarios']['tmp_name'];
        //echo "<pre>";print_r($archivo);exit;
        return $this->model->validarExcel($archivo, $request);
    }

    public function validarUsuario($request)
    {
        return $this->model->validarUsuario($request);
    }

    /**
     * ESTE METODO SEPARARA LOS PERFILES/ROLES POR USUARIOS
     * CADA PERFIL/ROL TENDRA UN CONJUNTO DE USUARIOS
     */
    private function formatearUsuariosPerfil(array $usuarios): array
    {
        $usuarios_x_perfil = [];

        foreach ($usuarios as $key => $value) {
            $perfil = $value['perfil'];
            //cada perfil tendra unos usuarios
            if (!isset($usuarios_x_perfil[$perfil])) {
                $usuarios_x_perfil[$perfil] = [];
            }
            $usuarios_x_perfil[$perfil][] = $value['usuario'];
        }

        return $usuarios_x_perfil;
    }

    public function crearUsuariosMasivo($request)
    {
        // $this->displayErrors();
        $heads = array(
            "`user`",
            "`pass`",
            "`fecha_creacion`",
            "`activo`",
            "`tipo_user`",
            "`rut_tecnico`",
            "`nombre_tec`",
            "`ape_tec`",
            "`empresa_aliada`",
            "`rut_creacion`",
            "`tipo_ejecutivo`",
        );

        $query = "INSERT INTO user_tec(" . implode(",", $heads) . ") VALUES ";
        $usuariosSql = array();

        $usuariosPer = array();
        foreach ($request->usuarios as $usuario) {
            $usuariosSql[] = sprintf(
                "('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",
                trim($usuario["usuario"]),
                Password::hash($usuario["password"]),
                date('Y-m-d h:i:s'),
                "1",
                trim($usuario["perfil"]),
                trim($usuario["rut"]),
                trim($usuario["nombre"]),
                trim($usuario["apellido"]),
                trim($usuario["empresa_aliada"]),
                Session::user()->dni,
                trim($usuario["tipo_ejecutivo"])
            );

            $usuariosPer[] = $usuario["usuario"];
            $queryLog = "INSERT INTO t2_acceso_usuario_log(usuario,usuario_accion,accion,fecha_registro) VALUES(:usuario,:usuario_sesion,:accion,NOW())";
            $this->db->statement($queryLog, array(
                ":usuario" => $usuario["usuario"],
                ":usuario_sesion" => Session::user()->username,
                ":accion" => "CREACION USUARIO MASIVO",
            ));
        }
        $usuariosSql = implode(",", $usuariosSql);
        $query .= $usuariosSql;

        $resp =  $this->db->statement($query);
        $resp->data = $request->usuarios;



        if (($request->usuario_modelo ?? '') != '') {
            $this->model->permisosPorUsuarioModel($usuariosPer, $request->usuario_modelo);
        } else {

            $obj_permisos = new PermisosKT2Model();
            $usuarios_x_perfil = $this->formatearUsuariosPerfil($request->usuarios ?? []);
            // ESTO PORQUE NO TODOS LOS USUARIOS CARGADOS EN EL EXCEL TENDRAN EL MISMO PERFIL, PUEDE QUE ALGUNOS SE ACTUALICE EL PERFIL
            foreach ($usuarios_x_perfil as $idperfil => $items) {
                $obj_permisos->adicionarPermisos($items, [], $idperfil);
            }
        }
        return $resp;
    }

    public function exportarUsuariosCreados($request)
    {
        return $this->view("Ajustes/tabla_usr_creados", array(
            "usuarios" => $request->usuarios,
        ));
    }

    public function exportarAcciones($request)
    {

        $heads = array(
            "id" => "ID",
            "usuario" => "Usuario",
            "rut" => "RUT",
            "nombre" => "Nombre ",
            "apellido" => "Apellido",
            "tipo_ejecutivo" => "Tipo Ejecutivo",
            "perfil" => "Perfil",
            "aliado" => "Empresa Aliada",
            "accion" => "Accion",
            "fecha_accion" => "Fecha Accion",
            "usuario_accion" => "Usuario Accion",
            "nombre_accion" => "Nombre Usuario Accion",
        );
        $query = "SELECT l.id, 
                l.usuario,
                u.rut_tecnico rut,
                u.nombre_tec nombre,
                u.ape_tec apellido,
                u.tipo_ejecutivo,
                p.nombre perfil,
                u.empresa_aliada aliado,
                l.accion,
                l.usuario_accion,
                CONCAT_WS(' ',ua.nombre_tec,ua.ape_tec) nombre_accion,
                l.fecha_registro fecha_accion
                FROM t2_acceso_usuario_log l
                INNER JOIN user_tec u ON u.user = l.usuario
                INNER JOIN perfiles p ON p.id = u.tipo_user
                INNER JOIN user_tec ua ON ua.user = l.usuario_accion
                WHERE DATE(l.fecha_registro) BETWEEN :desde AND :hasta";
        $request->desde = !!$request->desde ? $request->desde : date("Y-m-d");
        $request->hasta = !!$request->hasta ? $request->hasta : date("Y-m-d");
        $result = $this->db->select($query, array(
            ":desde" => $request->desde,
            ":hasta" => $request->hasta,
        ));


        return $this->view("Ajustes/tabla_acciones", array(
            "heads" => $heads,
            "data" => $result->data,
        ));
    }

    public function exportarPermisosUsuario($request)
    {
        $heads = array(
            "usuario" => "Usuario",
            "menu" => "Menu",
            "submenu" => "Submenu",
            "url" => "URL",
        );
        $query = "SELECT ac.usuario,m.nombre menu,s.nombre submenu,s.links url
                    FROM t2_web_extranet.menu m 
                    INNER JOIN sub_menu s ON m.id = s.menu_id
                    INNER JOIN t2_web_extranet.perfiles_relacion_2 ac ON s.id = ac.id_menu
                    WHERE s.estado = 1 AND s.links != '' AND s.nombre != ''";

        $result = $this->db->select($query);

        return $this->view("tabla_heads", array(
            "heads" => $heads,
            "data" => $result->data
        ));
    }

    public function eliminarUsuario($request)
    {
        $query = "UPDATE user_tec SET activo = -1 WHERE user = :user";
        $exe =  $this->db->statement($query, array(":user" => $request->user));

        $queryLog = "INSERT INTO t2_acceso_usuario_log(usuario,usuario_accion,accion,fecha_registro) VALUES(:usuario,:usuario_sesion,:accion,NOW())";
        $this->db->statement($queryLog, array(
            ":usuario" => $request->user,
            ":usuario_sesion" => Session::user()->username,
            ":accion" => "ELIMINAR USUARIO",
        ));

        return $exe;
    }

    public function getRoles()
    {
        try {
            $roles = array();

            $sql = "SELECT id, nombre, estado FROM {$this->table_perfiles}";

            $result = $this->db->select($sql);

            if (count($result->data) > 0) {
                foreach ($result->data as $row) {
                    $roles[] = array(
                        'id' => $row["id"],
                        'nombre' => $row["nombre"],
                        'estado' => intval($row["estado"])
                    );
                }
            }

            return array(
                'status' => true,
                'data' => $roles,
            );
        } catch (\Exception $e) {
            return array(
                'status' => false,
                'msg' => $e->getMessage(),
                'data' => array()
            );
        }
    }

    public function getPermissions($request)
    {
        try {
            $type = $request->type;
            $role = $request->role;
            $permisos = array();
            $permissionsRoles = array();
            $permiso_edit = array();

            $permisos = $this->modelPermisos->listarModulos(array(), true)->data;

            if ($type == "edit") {
                $sql_permissions_role = " SELECT menu_id FROM  {$this->table_perfiles_permisos} WHERE role_id = :role_id ";

                $result_permission = $this->db->select($sql_permissions_role, array(':role_id' => $role["id"]))->data;

                if (count($result_permission) > 0) {
                    foreach ($result_permission as $row) {
                        $permissionsRoles[] =  intval($row["menu_id"]);
                    }
                }

                foreach ($permisos as $key => $permiso) {
                    $permiso["checked"] = in_array($permiso["id"], $permissionsRoles);

                    foreach ($permiso["children"] as $key => $child) {
                        $permiso["children"][$key]["checked"] = in_array($child["id"], $permissionsRoles);

                        foreach ($permiso["children"][$key]["children"] as $keyChild => $grandChild) {
                            $permiso["children"][$key]["children"][$keyChild]["checked"] = in_array($grandChild["id"], $permissionsRoles);
                        }
                    }

                    $permiso_edit[] = $permiso;
                }
            }

            return array(
                'status' => true,
                'data' => $type == "edit" ? array(
                    'role' => $role,
                    'permisos' => $permiso_edit
                ) : array(
                    'role' => $role,
                    'permisos' => $permisos
                )
            );
        } catch (\Exception $e) {
            return array(
                'status' => false,
                'msg' => $e->getMessage(),
                'data' => array()
            );
        }
    }

    public function updateRolesPermissions($request)
    {
        try {
            $roleName = $request->roleName;
            $roleId = $request->roleId;
            $permissions = $request->permissions;

            $sql_role = "UPDATE {$this->table_perfiles} SET nombre = :nombre WHERE id = :id";
            $result_role = $this->db->statement($sql_role, array(':nombre' => $roleName, ':id' => $roleId));

            // UPDATE PERMISSIONS
            $sql_curr_permissions = "DELETE FROM {$this->table_perfiles_permisos} WHERE role_id = :role_id";
            $result_curr_permissions = $this->db->statement($sql_curr_permissions, array(':role_id' => $roleId));

            foreach ($permissions as $permiso) {
                $sql_permission = "INSERT INTO {$this->table_perfiles_permisos} (menu_id, role_id) VALUES (:menu_id, :role_id)";
                $result_permission = $this->db->statement($sql_permission, array(':menu_id' => $permiso,':role_id' => $roleId));
            }

            // UPDATE PERMISSION'S USERS BY ROLE
            $sql_users = "SELECT user FROM {$this->table_users} WHERE tipo_user = :role";

            $result_users = $this->db->select($sql_users, array(':role' => $roleId))->data;

            if (count($result_users) > 0) {
                foreach ($result_users as $user) {
                    $sql_delete_curr_permissions = "DELETE FROM {$this->table_acceso_usuarios} WHERE usuario = :usuario";
                    $result_delete_curr_permissions = $this->db->statement($sql_delete_curr_permissions, array(':usuario' => $user["user"]));

                    // NEW PERMISSIONS
                    foreach ($permissions as $permiso) {
                        $sql_new_permission = "INSERT INTO {$this->table_acceso_usuarios} (menu_id, usuario) VALUES (:menu_id, :usuario)";
                        $result_new_permission = $this->db->statement($sql_new_permission, array(':menu_id' => $permiso, ':usuario' => $user["user"]));
                    }
                }
            }

            return array(
                'status' => true,
                'data' => $result_users
            );
        } catch (\Exception $e) {
            return array(
                'status' => false,
                'msg' => $e->getMessage(),
                'data' => array()
            );
        }
    }

    public function saveRolesPermissions($request)
    {
        try {
            $roleName = $request->roleName;
            $permissions = $request->permissions;

            $sql_last = "SELECT id FROM {$this->table_perfiles} ORDER BY id DESC LIMIT 1";

            $lastIdRole = $this->db->find($sql_last)->data["id"];

            // CREATE ROLE 
            $sql_role = "INSERT INTO {$this->table_perfiles} (id, nombre, estado) VALUES (:id, :nombre, :estado)";

            $result_role = $this->db->statement($sql_role, array(
                ':id' => $lastIdRole + 1,
                ':nombre' => $roleName,
                ':estado' => 1
            ));

            $insertId = $result_role->insert_id;
            // CREATE PERMISSIONS
            foreach ($permissions as $permiso) {
                $sql_permission = "INSERT INTO {$this->table_perfiles_permisos} (menu_id, role_id) VALUES (:menu_id, :role_id)";

                $result_permission = $this->db->statement($sql_permission, array(
                    ':menu_id' => $permiso,
                    ':role_id' => $insertId
                ));
            }

            return array(
                'status' => true,
                'data' => $result_permission
            );
        } catch (\Exception $e) {
            return array(
                'status' => false,
                'msg' => $e->getMessage(),
                'data' => array()
            );
        }
    }
}
