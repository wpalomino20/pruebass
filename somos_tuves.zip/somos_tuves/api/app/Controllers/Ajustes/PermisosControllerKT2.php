<?php
namespace App\Controllers\Ajustes;

use App\Controllers\Controller;
use App\Models\Ajustes\PermisosKT2Model;
use App\Models\DB;
class PermisosControllerKT2 extends Controller{

    private $db;
    private $model;
    private $table = "perfiles_relacion_2";
    public function __construct(){
        $this->middleware();
        $this->db = new DB();
        $this->model = new PermisosKT2Model();
    }
    public function listarModulos($request,$toArray = true){
        return $this->model->listarModulos($request,$toArray);
    }
    public function listarModulosUsuario($request){
        $usuario = $request->usuario;
        return $this->model->listarPermisosUsuario($usuario);
    }
    public function adicionarPermisos($request){
        $usuarios = $request->usuarios;
        $permisos = $request->permisos;
        
        return $this->model
                    ->adicionarPermisos($usuarios,$permisos,  $request->role);
    }
    public function adicionarPermisosExcel($request){
        require_once '/var/www/t2/phpexcel/PHPExcel.php';

        $archivo = $_FILES['archivo']['tmp_name'];

        $usuarios = $this->model
                         ->usuariosExcel($archivo);
        $permisos = explode(",",$request->permisos);
        return $this->model
                    ->adicionarPermisos($usuarios,$permisos);
    }
    public function asignarPermisos($request){
        return $this->model
             ->asignarPermisos($request->usuarios,$request->permisos, $request->role);
    }
    public function asignarPermisosExcel($request){
        require_once '/var/www/t2/phpexcel/PHPExcel.php';

        $archivo = $_FILES['archivo']['tmp_name'];

        $usuarios = $this->model
                         ->usuariosExcel($archivo);
        $permisos = explode(",",$request->permisos);
        return $this->model
                    ->asignarPermisos($usuarios,$permisos);
    }
}