<?php

namespace App\Controllers\Ajustes;

use App\Controllers\Controller;
use App\Models\Session;
use App\Models\DB;

// function getTreeMenu($id = 0, $db) {
//     $query = "SELECT * FROM t2_menu WHERE menu_id_padre = {$id} ORDER BY nombre DESC ";
//     $menu = array();

//     $results = $db->select($query);

//     foreach($results->data as $d) {
//         $children = getTreeMenu($d['id'], $db);

//         if(!empty($children)) {
//             $menu[] = array_merge($d, array('children' => $children));
//         } else {
//             $menu[] = $d;
//         }
//     }

//     return $menu;
// }

class AgregarMenuController extends Controller {
    
    private $db;

    public function __construct() {
        $this->db = new DB();
    }

    public function index() {
        try {
            $menu = $this->getTreeMenu(0);

            return array(
                'message' => 'Carga Éxitosa',
                'status' => true,
                'data' => $menu
            );
        } catch (\Throwable $th) {
            return array(
                'message' => $th->getMessage(),
                'status' => false,
                'data' => array()
            );
        }
    }

    public function getTreeMenu($id = 0) {
        $query = "SELECT * FROM t2_menu WHERE menu_id_padre = {$id} ORDER BY nombre DESC ";
        $menu = array();
    
        $results = $this->db->select($query);
    
        foreach($results->data as $d) {
            $children = $this->getTreeMenu($d['id'], $db);
    
            if(!empty($children)) {
                $menu[] = array_merge($d, array('children' => $children));
            } else {
                $menu[] = $d;
            }
        }
    
        return $menu;        
    }

    public function edit($request) {
        if($request->menu_id) {
            $menu = $this->db->select("SELECT * FROM t2_menu WHERE id = $request->menu_id");
        }

        return $menu;
    }

    public function update($request) {
        $params = array(
            "nombre" => $request->nombre,
            "ruta" => $request->ruta,
            "estado" => $request->estado,
            "nivel" => $request->nivel,
            "menu_id_padre" => $request->menu_id_padre,
            'estado_desarrollo' => $request->estado_desarrollo,
            "fecha_ultima_visita" => date('Y-m-d h:i:s'),
        );

        $res = $this->db->statementUpdate("t2_menu", $params, array('id' => $request->id));

        return array(
            'message' => 'Actualización Éxitosa',
            'status' => true,
            'data' => $params
        );
    }

    public function store($request) {
        try {
            $parentId = 0;

            if($request->menu_id_padre) $parentId = $request->menu_id_padre;
            
            $params = array(
                "nombre" => $request->nombre,
                "ruta" => $request->ruta,
                "estado" => $request->estado,
                "nivel" => $request->nivel,
                "menu_id_padre" => $parentId,
                "icono" => "",
                "fecha_ultima_visita" => date('Y-m-d h:i:s'),
                "contador" => 0,
                'estado_desarrollo' => $request->estado_desarrollo,
                "usuario_creacion" => Session::user()->username,
                "fecha_creacion" => date('Y-m-d h:i:s'),
                "list_parents" => json_encode($request->parents)
            );

            $this->db->statementInsert('t2_menu', $params);

            return array(
                'request' => $request->all(),
                'message' => 'Creación Éxitosa',
                'status' => true,
                'data' => array()
            );
        } catch (\Throwable $th) {
            return array(
                'message' => $th->getMessage(),
                'status' => false,
                'data' => array()
            );
        }    
    }

    public function destroy($request) {
        if($request->menu_id) {
            $menuFound = $this->db->find("SELECT * FROM t2_menu WHERE id = {$request->menu_id}")->data;
            $children = $this->db->select("SELECT * FROM t2_menu WHERE menu_id_padre = {$menuFound['id']}")->data;

            foreach($children as $child) {
                $params = array(
                    'estado' => 0
                );
                $result = $this->db->statementUpdate("t2_menu",$params, array(
                    'id' => $child['id']
                ));
            }

            $resultParent = $this->db->statementUpdate("t2_menu", array('estado' => 0) , array('id' => $menuFound['id']));
        }

        return array(
            'message' => 'Eliminación Éxitosa',
            'status' => true,
            'data' => array()
        );    
    }
}