<?php 
namespace App\Controllers\Ajustes\Mantenedor;

use App\Controllers\Controller;
use App\Models\DB;
use App\Models\Session;
use App\Models\Ajustes\PermisosKT2Model;

class UsuariosModeloController extends Controller{

    private $db;
    private $model;

    public function __construct(){
        $this->db = new DB();
        $this->model = new PermisosKT2Model();
    }

    public function listarUsuariosModelo(){
        $query = "SELECT u.user, 
                CONCAT_WS(' ',u.nombre_tec,u.ape_tec) nombre,
                u.rut_tecnico,
                p.nombre perfil,
                u.empresa_aliada aliado,
                u.usuario_modelo modelo
                FROM user_tec u 
                INNER JOIN perfiles p ON p.id = u.tipo_user
                WHERE usuario_modelo = 1
                AND activo = 1";
        return $this->db->select($query);
        
    }
    public function guardarPermisoModelo($request){
        $res = $this->model->asignarPermisos($request->usuarios,$request->permisos);
        
        $query = "UPDATE user_tec SET usuario_modelo = 1 WHERE user = :usuario";
        return $this->db->statement($query,array(
            ":usuario" => $request->usuarios[0],
        ));
    }

    public function desactivarModelo($request){
        $query = "UPDATE user_tec SET usuario_modelo = 0 WHERE user = :usuario";
        return $this->db->statement($query,array(
            ":usuario" => $request->usuario,
        ));
    }

}