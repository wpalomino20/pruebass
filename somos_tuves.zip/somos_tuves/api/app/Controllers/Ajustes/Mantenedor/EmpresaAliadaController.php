<?php 
namespace App\Controllers\Ajustes\Mantenedor;

use App\Controllers\Controller;
use App\Models\DB;
use App\Models\Session;

class EmpresaAliadaController extends Controller{
    private $db;
    private $model;
    private $table_empresas;
    
    public function __construct() {
        $this->db = new DB();
        $this->table_empresas = "t2_empresas_aliadas";
    }

    public function index() {
        $query = "SELECT * FROM {$this->table_empresas}";

        $result = $this->db->select($query);

        return $result;
    }

    public function store($request) {
        $nombre = $request->nombre;

        $fields = array(
            'nombre_empresa' => $nombre,
            'activo' => 1
        );

        $result = $this->db->statementInsert($this->table_empresas, $fields);

        return array(
            'status' => true,
            'data' => $result
        );
    }

    public function update($request) {
        $nombre = $request->nombre;
        $state = $request->state ? 1 : 0;
        $id = $request->id;

        $fields = array(
            'nombre_empresa' => $nombre,
            'activo' => $state
        );

        $result = $this->db->statementUpdate($this->table_empresas, $fields, array(
            'id' => $id
        ));

        return $result;
    }

    public function destroy($request) {
        $id = $request->id;

        $query = "UPDATE {$this->table_empresas} SET activo = IF(activo = 1,0,1) WHERE id = '$id'";

        $result = $this->db->statement($query);

        $result->sql = $query;

        return $result;
    }
}