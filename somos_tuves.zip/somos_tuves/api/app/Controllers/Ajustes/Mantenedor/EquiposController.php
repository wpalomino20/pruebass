<?php 
namespace App\Controllers\Ajustes\Mantenedor;

use App\Controllers\Controller;
use App\Models\DB;
use App\Models\Session;

class EquiposController extends Controller{
    private $db;
    private $table_empresas;
    
    public function __construct() {
        $this->db = new DB();
    }

    public function listarEquipos($request){
        $query = "SELECT * FROM t2_equipos";
        return $this->db->select($query);
    }
    public function guardarEquipo($request){
        // return $request->all();
        $campos = array(
            "tipo_equipo" => $request->tipo_equipo,
            "modelo" => $request->modelo,
            "doc_sis" => $request->doc_sis,
        );
        if(!!$request->id){
            return $this->db->statementUpdate("t2_equipos",$campos,array(
                "id" => $request->id
            ));
        }else{
            return $this->db->statementInsert("t2_equipos",$campos);
        }
    }

    public function cambiarEstadoEquipo($request){
        $query = "UPDATE t2_equipos SET estado = IF(estado = 1,0,1) WHERE id = :id";

        return $this->db->statement($query,array(
            ":id" => $request->id
        ));
    }
}