<?php 
namespace App\Controllers\Ajustes\Mantenedor;

use App\Controllers\Controller;
use App\Models\DB;
use App\Models\Session;

class PerfilUsuarioController extends Controller{

    private $db;
    private $table_perfiles;
    
    public function __construct() {
        $this->db = new DB();
        $this->table_perfiles = "perfiles";
    }

    public function init_perfiles() {
        $query = "
            SELECT
            *
            FROM {$this->table_perfiles}
        ";

        $result = $this->db->select($query);

        return $result;
    }

    public function perfilesStore($request) {
        $nombre = $request->nombre;

        $fields = array(
            'nombre' => $nombre,
            'estado' => 1
        );

        $result = $this->db->statementInsert($this->table_perfiles, $fields);

        return $result;
    }

    
    public function perfilesUpdate($request) {
        $nombre = $request->nombre;
        $estado = $request->activo ? 1 : 0;
        $id = $request->id;

        $fields = array(
            'nombre' => $nombre,
            'estado' => $estado
        );

        $result = $this->db->statementUpdate($this->table_perfiles, $fields, array(
            'id' => $id
        ));

        return $result;
    }

    public function perfilesDestroy($request) {
        $id = $request->id;

        $query = "UPDATE perfiles SET estado = IF(estado=1,0,1) WHERE id = '$id'";

        $result = $this->db->statement($query);

        return $result;
    }


}