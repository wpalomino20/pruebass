<?php
namespace App\Controllers\Ajustes;

use App\Controllers\Controller;
use App\Models\Ajustes\PermisosModel;
use App\Models\DB;
class PermisosController extends Controller{

    private $db;
    private $model;
    public function __construct(){
        $this->middleware();
        $this->db = new DB();
        $this->model = new PermisosModel();
    }

    public function getTreeMenu($id = 0) {
        $query = "
            SELECT
                id,
                nombre,
                nivel,
                false as checked,
                estado_desarrollo,
                menu_id_padre as padre,
                list_parents as parents
            FROM t2_menu
            WHERE menu_id_padre = {$id}
            ORDER BY nombre DESC
        ";

        $menu = array();
    
        $results = $this->db->select($query);
    
        foreach($results->data as $d) {
            $children = $this->getTreeMenu($d['id']);
    
            if(!empty($children)) {
                $menu[] = array_merge(array(
                    'id' => intval($d['id']),
                    'nombre' => $d['nombre'],
                    'nivel' => intval($d['nivel']),
                    'checked' => !!$d['checked'],
                    'estado_desarrollo' => $d['estado_desarrollo'],
                    'padre' => intval($d['padre']),
                    'parents' => json_decode($d['parents'])
                ), array('children' => $children));
            } else {
                $menu[] = array(
                    'id' => intval($d['id']),
                    'nombre' => $d['nombre'],
                    'nivel' => intval($d['nivel']),
                    'checked' => !!$d['checked'],
                    'padre' => intval($d['padre']),
                    'parents' => json_decode($d['parents'])
                );
            }
        }
    
        return $menu;        
    }

    public function listarModulosTest($request,$toArray = true){
        $menu = $this->getTreeMenu(0);

        return array(
            'message' => 'Carga Éxitosa',
            'status' => true,
            'data' => $menu
        );
    }

    public function listarModulos($request,$toArray = true){
        
        $sql = "SELECT s1.id menu_id,s1.nombre menu,s1.nivel,s2.id submenu_id,s2.nombre submenu_nombre,s2.nivel submenu_nivel,s2.estado_desarrollo
                FROM t2_menu s2
                INNER JOIN t2_menu s1 ON s2.menu_id_padre = s1.id
                WHERE s2.estado = 1 AND s1.estado = 1";
        $res = $this->db->select($sql);
        $modulos = array();
        foreach($res->data as $row){
            $modulos[$row["menu_id"]]["id"] = intval($row["menu_id"]);
            $modulos[$row["menu_id"]]["nombre"] = $row["menu"];
            $modulos[$row["menu_id"]]["nivel"] = intval($row["nivel"]);
            $modulos[$row["menu_id"]]["checked"] = false;
            $modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["id"] = intval($row["submenu_id"]);
            $modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["nombre"] = $row["submenu_nombre"];
            $modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["nivel"] = intval($row["submenu_nivel"]);
            $modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["padre"] = intval($row["menu_id"]);
            $modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["estado_desarrollo"] = $row["estado_desarrollo"];
            $modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["checked"] = false;
        }
        if($toArray) $modulos = $this->toArray($modulos);
        $res->data = $modulos;

        return $res;
    }
	
	public function listarModulos_v2($request,$toArray = true){
	 $query = "select 
				s1.id,s1.nombre,s1.ruta,s1.icono,s1.estado_desarrollo,s1.menu_id_padre,(s1.nivel+1) as nivel,
				(select menu_id_padre from t2_menu as menu0 where menu0.id = s1.menu_id_padre ) as idPadre
			FROM
			t2_menu s1 ORDER by s1.nivel,s1.nombre,s1.ruta";
					
        $res = $this->db->select($query);
        $data = $res->data;
        $modulos = array();

        foreach($data as $menu){
			if($menu["nivel"]=="1"){
				$modulos[$menu["id"]]["id"] = intval($menu["id"]);
				$modulos[$menu["id"]]["nombre"] = $menu["nombre"];
				$modulos[$menu["id"]]["nivel"] = intval($menu["nivel"]);
				$modulos[$menu["id"]]["padre"] = 0;
				$modulos[$menu["id"]]["checked"] = false;
			
			}
			
			if($menu["nivel"]=="2"){
				$modulos[$menu["menu_id_padre"]]["children"][$menu["id"]]["id"] = intval($menu["id"]);
				$modulos[$menu["menu_id_padre"]]["children"][$menu["id"]]["nombre"] = $menu["nombre"];
				$modulos[$menu["menu_id_padre"]]["children"][$menu["id"]]["nivel"] = intval($menu["nivel"]);
				$modulos[$menu["menu_id_padre"]]["children"][$menu["id"]]["padre"] = intval($menu["menu_id_padre"]);
				$modulos[$menu["menu_id_padre"]]["children"][$menu["id"]]["estado_desarrollo"] = $menu["estado_desarrollo"];
				$modulos[$menu["menu_id_padre"]]["children"][$menu["id"]]["checked"] = false;
			
			}
			
			if($menu["nivel"]=="3"){
				$modulos[$menu["idPadre"]]["children"][$menu["menu_id_padre"]]["children"][$menu["id"]]["id"] = intval($menu["id"]);
				$modulos[$menu["idPadre"]]["children"][$menu["menu_id_padre"]]["children"][$menu["id"]]["nombre"] = $menu["nombre"];
				$modulos[$menu["idPadre"]]["children"][$menu["menu_id_padre"]]["children"][$menu["id"]]["nivel"] = intval($menu["nivel"]);
				$modulos[$menu["idPadre"]]["children"][$menu["menu_id_padre"]]["children"][$menu["id"]]["padre"] = intval($menu["menu_id_padre"]);
				$modulos[$menu["idPadre"]]["children"][$menu["menu_id_padre"]]["children"][$menu["id"]]["estado_desarrollo"] = $menu["estado_desarrollo"];
				$modulos[$menu["idPadre"]]["children"][$menu["menu_id_padre"]]["children"][$menu["id"]]["checked"] = false;
			
			}
			
        }
	
       /* 
        $sql = "SELECT s1.id menu_id,s1.nombre menu,s1.nivel,s2.id submenu_id,s2.nombre submenu_nombre,s2.nivel submenu_nivel,s2.estado_desarrollo
                FROM t2_menu s2
                INNER JOIN t2_menu s1 ON s2.menu_id_padre = s1.id
                WHERE s2.estado = 1 AND s1.estado = 1";
        $res = $this->db->select($sql);
        $modulos = array();
        foreach($res->data as $row){
            $modulos[$row["menu_id"]]["id"] = intval($row["menu_id"]);
            $modulos[$row["menu_id"]]["nombre"] = $row["menu"];
            $modulos[$row["menu_id"]]["nivel"] = intval($row["nivel"]);
            $modulos[$row["menu_id"]]["checked"] = false;
            $modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["id"] = intval($row["submenu_id"]);
            $modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["nombre"] = $row["submenu_nombre"];
            $modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["nivel"] = intval($row["submenu_nivel"]);
            $modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["padre"] = intval($row["menu_id"]);
            $modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["estado_desarrollo"] = $row["estado_desarrollo"];
            $modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["checked"] = false;
        }*/
		//echo print_r($modulos);
        if($toArray) $modulos = $this->toArray($modulos);
        $res->data = $modulos;

        return $res;
    }

    /* LISTA MÓUDLOS - BUSCAR PERMISOS POR USUARIO */

    public function getTreeMenuByUser($id = 0, $user = "") {
        $sql = "
            SELECT
                m.id,
                m.nombre,
                m.nivel,
                m.estado_desarrollo,
                m.menu_id_padre as padre
            FROM t2_menu m
            INNER JOIN t2_acceso_usuario a ON a.menu_id = m.id
            WHERE a.usuario = '{$user}' AND m.estado = 1 AND m.menu_id_padre = '{$id}'
        ";

        $menu = array();
    
        $results = $this->db->select($sql);
    
        foreach($results->data as $d) {
            $children = $this->getTreeMenu($d['id'], $user);
    
            if(!empty($children)) {
                $menu[] = array_merge(array(
                    'id' => intval($d['id']),
                    'nombre' => $d['nombre'],
                    'nivel' => intval($d['nivel']),
                    'estado_desarrollo' => $d['estado_desarrollo'],
                    'checked' => true,
                    'padre' => intval($d['padre'])
                ), array('children' => $children));
            } else {
                $menu[] = array(
                    'id' => intval($d['id']),
                    'nombre' => $d['nombre'],
                    'nivel' => intval($d['nivel']),
                    'checked' => true,
                    'padre' => intval($d['padre'])
                );
            }
        }
    
        return $menu;   
    }

    public function listarModulosUsuarioDev($request) {
        $menu = $this->getTreeMenuByUser(0, $request->usuario);

        return array(
            'message' => 'Carga Éxitosa',
            'status' => true,
            'data' => $menu
        );        
    }

	public function listarModulosUsuario_V2($request){
	
		$usuario = $request->usuario;
		/*
        if($usuario == "") return array();
        $sql = "SELECT s1.id menu_id,s1.nombre menu,s1.nivel,s2.id submenu_id,s2.nombre submenu_nombre,s2.nivel submenu_nivel,s2.estado_desarrollo
                FROM t2_menu s2
                INNER JOIN t2_menu s1 ON s2.menu_id_padre = s1.id
                INNER JOIN t2_acceso_usuario ac ON s2.id = ac.menu_id
                WHERE s2.estado = 1 AND s1.estado = 1 AND ac.usuario = :usuario";

        $res = $this->db->select($sql,array(
            ":usuario" => $usuario
        ));
		
		*/
        $query = "select 
				s1.id,s1.nombre,s1.ruta,s1.icono,s1.estado_desarrollo,s1.menu_id_padre,(s1.nivel+1) as nivel,
				(select menu_id_padre from t2_menu as menu0 where menu0.id = s1.menu_id_padre ) as idPadre
			FROM
				t2_acceso_usuario as  ac
			INNER JOIN t2_menu s1  ON ac.menu_id = s1.id
				where ac.usuario =:usuario ORDER by s1.nivel,s1.nombre,s1.ruta";
					
        $res = $this->db->select($query,array(
            ":usuario" => $usuario
        ));
        $data = $res->data;
        $arr = array();
		
		$permisos_usuarios = array();
        foreach($data as $menu){
			if($menu["nivel"]=="1"){
				$permisos_usuarios[$menu["id"]]["id"] = intval($menu["id"]);
				$permisos_usuarios[$menu["id"]]["nombre"] = $menu["nombre"];
				$permisos_usuarios[$menu["id"]]["nivel"] = intval($menu["nivel"]);
				$permisos_usuarios[$menu["id"]]["padre"] = 0;
				$permisos_usuarios[$menu["id"]]["checked"] = false;
			
			}
			
			if($menu["nivel"]=="2"){
				$permisos_usuarios[$menu["menu_id_padre"]]["children"][$menu["id"]]["id"] = intval($menu["id"]);
				$permisos_usuarios[$menu["menu_id_padre"]]["children"][$menu["id"]]["nombre"] = $menu["nombre"];
				$permisos_usuarios[$menu["menu_id_padre"]]["children"][$menu["id"]]["nivel"] = intval($menu["nivel"]);
				$permisos_usuarios[$menu["menu_id_padre"]]["children"][$menu["id"]]["padre"] = intval($menu["menu_id_padre"]);
				$permisos_usuarios[$menu["menu_id_padre"]]["children"][$menu["id"]]["estado_desarrollo"] = $menu["estado_desarrollo"];
				$permisos_usuarios[$menu["menu_id_padre"]]["children"][$menu["id"]]["checked"] = false;
			
			}
			
			if($menu["nivel"]=="3"){
				$permisos_usuarios[$menu["idPadre"]]["children"][$menu["menu_id_padre"]]["children"][$menu["id"]]["id"] = intval($menu["id"]);
				$permisos_usuarios[$menu["idPadre"]]["children"][$menu["menu_id_padre"]]["children"][$menu["id"]]["nombre"] = $menu["nombre"];
				$permisos_usuarios[$menu["idPadre"]]["children"][$menu["menu_id_padre"]]["children"][$menu["id"]]["nivel"] = intval($menu["nivel"]);
				$permisos_usuarios[$menu["idPadre"]]["children"][$menu["menu_id_padre"]]["children"][$menu["id"]]["padre"] = intval($menu["menu_id_padre"]);
				$permisos_usuarios[$menu["idPadre"]]["children"][$menu["menu_id_padre"]]["children"][$menu["id"]]["estado_desarrollo"] = $menu["estado_desarrollo"];
				$permisos_usuarios[$menu["idPadre"]]["children"][$menu["menu_id_padre"]]["children"][$menu["id"]]["checked"] = false;
			
			}
		}

       // $permisos_usuarios = array_values($arr);
        //return $arr;
		
		 $permisos = $this->listarModulos_v2($request,false);
        $permisos = $permisos->data;
        foreach($permisos as $key => $permiso){
            $permisos[$key]["checked"] = @!!$permisos_usuarios[$key];
            foreach($permiso["children"] as $keySubMenu => $submenu){
                $permisos[$key]["children"][$keySubMenu]["checked"] = @!!$permisos_usuarios[$key]["children"][$keySubMenu];
				foreach($submenu["children"] as $keySubMenu1 => $submenu1){
					$permisos[$key]["children"][$keySubMenu]["children"][$keySubMenu1]["checked"] = @!!$permisos_usuarios[$key]["children"][$keySubMenu]["children"][$keySubMenu1];
				}
            }
        }
        $permisos = $this->toArray($permisos);
        return array(
            "status" => true,
            "data" => $permisos,
        );
		
    }

    public function listarModulosUsuario($request){
        $usuario = $request->usuario;
        if($usuario == "") return array();
        $sql = "SELECT s1.id menu_id,s1.nombre menu,s1.nivel,s2.id submenu_id,s2.nombre submenu_nombre,s2.nivel submenu_nivel,s2.estado_desarrollo
                FROM t2_menu s2
                INNER JOIN t2_menu s1 ON s2.menu_id_padre = s1.id
                INNER JOIN t2_acceso_usuario ac ON s2.id = ac.menu_id
                WHERE s2.estado = 1 AND s1.estado = 1 AND ac.usuario = :usuario";

        $res = $this->db->select($sql,array(
            ":usuario" => $usuario
        ));
        $permisos_usuarios = array();
        foreach($res->data as $row){
            $permisos_usuarios[$row["menu_id"]]["id"] = $row["menu_id"];
            $permisos_usuarios[$row["menu_id"]]["nombre"] = $row["menu"];
            $permisos_usuarios[$row["menu_id"]]["nivel"] = intval($row["nivel"]);
            $permisos_usuarios[$row["menu_id"]]["checked"] = false;
            $permisos_usuarios[$row["menu_id"]]["children"][$row["submenu_id"]]["id"] = intval($row["submenu_id"]);
            $permisos_usuarios[$row["menu_id"]]["children"][$row["submenu_id"]]["nombre"] = $row["submenu_nombre"];
            $permisos_usuarios[$row["menu_id"]]["children"][$row["submenu_id"]]["nivel"] = intval($row["submenu_nivel"]);
            $permisos_usuarios[$row["menu_id"]]["children"][$row["submenu_id"]]["padre"] = intval($row["menu_id"]);
            $permisos_usuarios[$row["menu_id"]]["children"][$row["submenu_id"]]["estado_desarrollo"] = $row["estado_desarrollo"];
            $permisos_usuarios[$row["menu_id"]]["children"][$row["submenu_id"]]["checked"] = false;
        }

        $permisos = $this->listarModulos($request,false);
        $permisos = $permisos->data;
        foreach($permisos as $key => $permiso){
            $permisos[$key]["checked"] = @!!$permisos_usuarios[$key];
            foreach($permiso["children"] as $keySubMenu => $submenu){
                $permisos[$key]["children"][$keySubMenu]["checked"] = @!!$permisos_usuarios[$key]["children"][$keySubMenu];
            }
        }
        $permisos = $this->toArray($permisos);
        return array(
            "status" => true,
            "data" => $permisos,
        );
    }
	
    public function adicionarPermisos($request){
        $usuarios = $request->usuarios;
        $permisos = $request->permisos;
        
        return $this->model
                    ->adicionarPermisos($usuarios,$permisos);
    }
    public function adicionarPermisosExcel($request){
        require_once '/var/www/t2/phpexcel/PHPExcel.php';

        $archivo = $_FILES['archivo']['tmp_name'];

        $usuarios = $this->model
                         ->usuariosExcel($archivo);
        $permisos = explode(",",$request->permisos);
        return $this->model
                    ->adicionarPermisos($usuarios,$permisos);
    }
    public function asignarPermisos($request){
        return $this->model
             ->asignarPermisos($request->usuarios,$request->permisos);
    }
    public function asignarPermisosExcel($request){
		require_once '/var/www/t2/phpexcel/PHPExcel.php';

        $archivo = $_FILES['archivo']['tmp_name'];

        $usuarios = $this->model
                         ->usuariosExcel($archivo);
						 
        $permisos = explode(",",$request->permisos);
		
        return $this->model
                    ->asignarPermisos($usuarios,$permisos);
    }

    private function toArray($array){
        sort($array);
        foreach($array as $key => $mod){
            sort($array[$key]["children"]);
			foreach($array[$key]["children"] as $keyy => $modd){
				sort($array[$key]["children"][$keyy]["children"]);
			}
        }
        return $array;
    }
}