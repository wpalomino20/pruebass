<?php
namespace App\Exceptions;

use App\Http\Response;
use Exception;

class BadRequestException extends Exception{

    public function __construct($message, $code = Response::HTTP_BAD_REQUEST, $previous = null) {
        parent::__construct($message, $code, $previous);
    }

    public function __toString() {
        return __CLASS__ . ": [{$this->code}]: {$this->message}\n";
    }

    public function errorDetails() {
        return "Page Not found";
    }


}