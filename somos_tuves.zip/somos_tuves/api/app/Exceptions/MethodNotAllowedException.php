<?php
namespace App\Exceptions;

use App\Http\Response;
use Exception;

class MethodNotAllowedException extends Exception{
    
    public function __construct($message, $code = Response::HTTP_METHOD_NOT_ALLOWED, $previous = null) {
        parent::__construct($message, $code, $previous);
    }

    public function __toString() {
        return __CLASS__ . ": [{$this->code}]: {$this->message}\n";
    }
    public function errorDetails() {
        return "Method Not Allowed";
    }
}