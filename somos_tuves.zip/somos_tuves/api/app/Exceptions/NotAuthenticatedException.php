<?php
namespace App\Exceptions;

use App\Http\Response;
use Exception;

class NotAuthenticatedException extends Exception{

    public function __construct($message = "No tiene una sesión activa, favor de reiniciar.", $code = Response::HTTP_FORBIDDEN, $previous = null) {
        parent::__construct($message, $code, $previous);
    }

    public function __toString() {
        return __CLASS__ . ": [{$this->code}]: {$this->message}\n";
    }

    public function errorDetails() {
        return "Not Authenticated";
    }


}