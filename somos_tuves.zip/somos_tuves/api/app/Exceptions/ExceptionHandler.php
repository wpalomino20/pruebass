<?php
namespace App\Exceptions;

use App\Http\Response;
use App\Models\Session;
class ExceptionHandler{
    public static function handler($exception){
        $response = array(
            "message" => $exception->getMessage(),
            "status" => false,
        );
        if(Session::user()->is_developer){
            $response["track"] = self::trace($exception);
        }
        Response::json($response,$exception->getCode());
    }
    private static function trace($exp){
        $arrTrace = array();
        foreach($exp->getTrace() as $trace){
            $arrTrace[] = array(
                "file" => $trace["file"],
                "line" => $trace["line"],
                "function" => $trace["function"],
                "class" => $trace["class"],
            );
        }
        return $arrTrace;
    }
}