<?php

namespace App\Utils;

class Password
{

    public static function hash($password)
    {
        //return crypt($value);
        return $hash = password_hash($password, PASSWORD_DEFAULT);
    }

    public static function generate()
    {
        $characters = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ@+-*#!";
        $charactersLength = strlen($characters);
        $result = "";
        for ($i = 0; $i < 15; $i++) {
            $result .= $characters[rand(0, $charactersLength-1)];
        }

        return (object) array(
            "hash" => self::hash($result),
            "password" => $result,
        );
    }
    
    public static function validate($password, $password_hash)
    {
        // return crypt($password, $password_hash) == $password_hash;
        if (password_verify($password, $password_hash)) {
            return true;
        } else {
            return false;
        }
    }
}
