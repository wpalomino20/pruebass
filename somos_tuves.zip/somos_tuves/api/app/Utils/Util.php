<?php

namespace App\Utils;

use DatePeriod;
use DateTime;
use DateInterval;

class Util
{

    public static function replaceSpecialCharacters($value, $replaceBy = "")
    {
        $chars = array("°", "!", "\"", "#", "$", "%", "&", "/", "(", ")", "=", "?", "¡", "+", "*", "[", "]", "{", "}", "_", "-", "ñ", "Ñ", "|", "\\", "'", "¿", "<", ">", "~");

        return str_replace($chars, $replaceBy, $value);
    }
    public static function replaceSpecialCharactersFull($value)
    {

        $value = preg_replace("/á|à|â|ã|ª/", "a", $value);
        $value = preg_replace("/Ã/", "A", $value);
        $value = preg_replace("/é|è|ê/", "e", $value);
        $value = preg_replace("/É|È|Ê/", "E", $value);
        $value = preg_replace("/í|ì|î/", "i", $value);
        $value = preg_replace("/Í|Ì|Î/", "i", $value);
        $value = preg_replace("/ó|ò|ô|õ|º/", "o", $value);
        $value = preg_replace("/Ó|Ò|Ô|Õ/", "O", $value);
        $value = preg_replace("/ú|ù|û/", "u", $value);
        $value = preg_replace("/Ú|Ù|Û/", "U", $value);
        $value = preg_replace("/ñ/", "n", $value);
        $value = preg_replace("/Ñ/", "N", $value);
        $value = str_replace(" ", "_", $value);

        $value = preg_replace('/[^a-zA-Z0-9_.-]/', '', $value);
        $value = str_replace("_", " ", $value);
//        $value = mb_convert_encoding($value, 'UTF-8', '');
        $value = iconv( 'UTF-8', '',$value);
        return $value;
    }

    public static function splitAndJoin($text, $separator = ",", $join = " ", $length = -1)
    {
        $splittedValues = explode($separator, $text);
        foreach ($splittedValues as $key => $value) {
            $value = trim($value);
            if (in_array($value, array("undefined", ""))) {
                unset($splittedValues[$key]);
            } else {
                $splittedValues[$key] = $value;
            }
        }
        $length = $length - 1 ? count($splittedValues) : $length;
        $splittedValues = array_slice($splittedValues, 0, $length);
        return implode($join, $splittedValues);
    }
    public static function rechazoOtros($value)
    {
        $excepcion = array(
            "NO ENVIA ACREDITACION",
            "PROBLEMA NO CUMPLE NORMAS TECNICAS",
            "PROBLEMA ORDENES",
            "PROBLEMAS NIVELES",
            "CLIENTE NO CONFORME",
            "PROBLEMA APROVISIONAMIENTO",
            "DIRECCION DE INSTALACION INCORRECTA "
        );
        if (in_array(trim($value), $excepcion) || !$value) {
            return $value;
        }
        return "OTROS";
    }

    public function ipAddress()
    {
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && $_SERVER['HTTP_X_FORWARDED_FOR'] != '') {
            $ipCliente =
                (!empty($_SERVER['REMOTE_ADDR'])) ?
                $_SERVER['REMOTE_ADDR']
                : ((!empty($_ENV['REMOTE_ADDR'])) ?
                    $_ENV['REMOTE_ADDR']
                    :
                    "unknown");

            $entradasL = preg_split('[, ]', $_SERVER['HTTP_X_FORWARDED_FOR']);

            reset($entradasL);
            while (list(, $entradaActual) = each($entradasL)) {
                $entradaActual = trim($entradaActual);
                if (preg_match("/^([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)/", $entradaActual, $listaIPs)) {
                    $ipPrivada = array(
                        '/^0\./',
                        '/^127\.0\.0\.1/',
                        '/^192\.168\..*/',
                        '/^172\.((1[6-9])|(2[0-9])|(3[0-1]))\..*/',
                        '/^10\..*/'
                    );

                    $ipEncontrada = preg_replace($ipPrivada, $ipCliente, $listaIPs[1]);

                    if ($ipCliente != $ipEncontrada) {
                        $ipCliente = $ipEncontrada;
                        break;
                    }
                }
            }
        } else {
            $ipCliente =
                (!empty($_SERVER['REMOTE_ADDR'])) ?
                $_SERVER['REMOTE_ADDR']
                : ((!empty($_ENV['REMOTE_ADDR'])) ?
                    $_ENV['REMOTE_ADDR']
                    :
                    "unknown");
        }

        return $ipCliente;
    }

    public function getSuffixesT4Months($date1,$date2){

        $min_month = date("Y_m",strtotime(date("Y-m")." -1 months"));
        $d1 = date("Y_m",strtotime($date1));
        $d2 = date("Y_m",strtotime($date2));
        $month = date("Y_m");

        if($d1 > $month){
            return array();
        }
        if($d2 > $month){
            $date2 = date("Y-m-d");
        }
        if($date1 == $date2 && $d2 >= $min_month){
            return array(
                ""
            );
        }
        if($date1 == $date2){
            return array(
                date("_Y_m",strtotime($date1)),
            );
        }
        $period = new DatePeriod(
            new DateTime($date1),
            new DateInterval("P1M"),
            new DateTime(date("Y-m-d",strtotime($date2." +1 months")))
        );
        $suffixes = array();
        foreach($period as $value){
            $month = $value->format("Y_m");
            if($month < $min_month){
                $suffixes[] = "_".$month;
            }
        }
        $monthDateEnd = date("Y_m",strtotime($date2));
        // echo "$d2|$min_month";
        if(count($suffixes) === 0 || $d2 >= $min_month){
            $suffixes[] = "";
        }
        return $suffixes;
    }
}
