<?php
namespace App\Models;

use App\Models\AuthModel;
use stdClass;

class Session{

    private static $instance;
    private function __construct(){
        
    }
    public static function user(){
        if(!self::$instance){
            self::$instance = new stdClass;

            self::$instance->permisos = array();
            $sessionPhpKeys = array("username" => "user","dni" => "dni","aliado" => "aliado","tipo_user" => "tipo_user","nombre" => "nombre");
            foreach($sessionPhpKeys as $key => $value){
                self::$instance->{$key} = $_SESSION[$value];
            }
            $res = new AuthModel();
            $usu = $res->user();
            if(!!$usu){
                foreach($usu as $key => $value){
                    self::$instance->{$key} = $value;
                }
            }
            self::$instance->user = self::$instance->username;
            
        }
        return self::$instance;
    }
    public static function authenticated(){
        self::user();
        return !is_null(self::$instance->username);
    }

    public static function refresh(){
        $user = self::user()->username;
        $auth = new AuthModel();
        $auth->refreshToken($user);
    }
}
