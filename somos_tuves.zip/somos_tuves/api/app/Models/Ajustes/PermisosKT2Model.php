<?php

namespace App\Models\Ajustes;

use App\Models\DB;
use PHPExcel_IOFactory;
use App\Models\Session;
use Exception;

class PermisosKT2Model
{

    private $db;
    private $tabla = "t2_acceso_usuario";
    private $table_perfiles_permisos;
    private $table_user_tec;

    public function __construct() {
        $this->db = new DB();
        $this->table_perfiles_permisos = "perfiles_permisos";
        $this->table_user_tec = "user_tec";
    }

    protected static function formateoNivelesMenu(array $listado) : array
    {
        $modulos = [];
        foreach ($listado as $row) {
            $modulos[$row["menu_id"]]["id"] = intval($row["menu_id"]);
            $modulos[$row["menu_id"]]["nombre"] = $row["menu"];
            $modulos[$row["menu_id"]]["nivel"] = intval($row["nivel"]);
            $modulos[$row["menu_id"]]["checked"] = false;


            $modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["id"] = intval($row["submenu_id"]);
            $modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["nombre"] = $row["submenu_nombre"];
            $modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["nivel"] = intval($row["submenu_nivel"]);
            $modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["padre"] = intval($row["menu_id"]);
            $modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["checked"] = false;

            //nivel 3
            $modulos[$row["menu_id"]]["children"][$row["submenu_id"]]["children"][] = array(
                "id" => intval($row["submenu_3_id"]),
                "nombre" => $row["submenu_3_nombre"],
                "nivel" => intval($row["submenu_3_nivel"]),
                "padre" => intval($row["submenu_id"]),
                "checked" => false
            );
        }
        return $modulos;
    }
    
    public function queryListarModulos(){
        $sql = "SELECT
                m.id AS menu_id,
                m.nombre AS menu,
                1 AS nivel,
                s.id AS submenu_id,
                s.nombre AS submenu_nombre,
                2 submenu_nivel,
                m3.id AS submenu_3_id, 
                m3.nombre AS submenu_3_nombre,
                3 submenu_3_nivel
            FROM t2_menu as m
            INNER JOIN t2_menu s ON m.id = s.menu_id_padre
            INNER JOIN t2_menu m3 ON m3.menu_id_padre = s.id
            WHERE s.estado = 1 AND m.estado = 1 AND m3.estado = 1 AND s.estado = 1 AND m.estado = 1
            AND s.nombre != ''";
        $res = $this->db->select($sql);
        return $res;
    }

    public function listarModulos($request, $toArray)
    {
        $res = $this->queryListarModulos();

        $modulos = self::formateoNivelesMenu($res->data);
        if ($toArray) $modulos = $this->toArray($modulos);
        $res->data = $modulos;
        return $res;
    }

    public function listarPermisosUsuario($usuario)
    {
        if ($usuario == "") return array();
        $sql = "SELECT
                m.id AS menu_id,
                m.nombre AS menu,
                1 AS nivel,
                s.id AS submenu_id,
                s.nombre AS submenu_nombre,
                2 AS submenu_nivel,
                m3.id AS submenu_3_id,
                m3.nombre AS submenu_3_nombre,
                3 AS submenu_3_nivel
            FROM t2_menu AS m
            INNER JOIN t2_menu AS s ON m.id = s.menu_id_padre
            INNER JOIN t2_menu AS m3 ON m3.menu_id_padre = s.id
            INNER JOIN t2_acceso_usuario ac ON ac.menu_id = m3.id
            WHERE
                s.estado = 1
            AND s.nombre != ''
            AND ac.usuario = :usuario";

        $res = $this->db->select($sql, array(
            ":usuario" => $usuario
        ));
        $permisos_usuarios = array();
        foreach ($res->data as $row) {
            $permisos_usuarios[$row["menu_id"]]["id"] = $row["menu_id"];
            $permisos_usuarios[$row["menu_id"]]["nombre"] = $row["menu"];
            $permisos_usuarios[$row["menu_id"]]["nivel"] = intval($row["nivel"]);
            $permisos_usuarios[$row["menu_id"]]["checked"] = false;
            //nivel 2
            $permisos_usuarios[$row["menu_id"]]["children"][$row["submenu_id"]]["id"] = intval($row["submenu_id"]);
            $permisos_usuarios[$row["menu_id"]]["children"][$row["submenu_id"]]["nombre"] = $row["submenu_nombre"];
            $permisos_usuarios[$row["menu_id"]]["children"][$row["submenu_id"]]["nivel"] = intval($row["submenu_nivel"]);
            $permisos_usuarios[$row["menu_id"]]["children"][$row["submenu_id"]]["padre"] = intval($row["menu_id"]);
            $permisos_usuarios[$row["menu_id"]]["children"][$row["submenu_id"]]["checked"] = false;
            //nivel 3
            $permisos_usuarios[$row["menu_id"]]["children"][$row["submenu_id"]]["children"][] = array(
                "id" => intval($row["submenu_3_id"]),
                "nombre" => $row["submenu_3_nombre"],
                "nivel" => intval($row["submenu_3_nivel"]),
                "padre" => intval($row["submenu_id"]),
                "checked" => false
            );
            
        }

        $sql = "SELECT * FROM `t2_acceso_usuario` WHERE usuario = :usuario";
        $resultado = $this->db->selectObject($sql, [':usuario' => $usuario]);
        $solo_id = array_column($resultado->data, 'menu_id');
        
        $permisos = $this->listarModulos($request, false);

        $permisos = $permisos->data;
        
        foreach ($permisos as $key => $permiso) {
            $permisos[$key]["checked"] = @!!$permisos_usuarios[$key];
            foreach ($permiso["children"] as $keySubMenu => $submenu) {
                $permisos[$key]["children"][$keySubMenu]["checked"] = @!!$permisos_usuarios[$key]["children"][$keySubMenu];
                foreach ($submenu["children"] as $keySubMenu3 => $submenu3) {    
                    $permisos[$key]["children"][$keySubMenu]["children"][$keySubMenu3]["checked"] = in_array($permisos[$key]["children"][$keySubMenu]["children"][$keySubMenu3]["id"], $solo_id);
                }
            }
        }
        $permisos = $this->toArray($permisos);
        return array(
            "status" => true,
            "data" => $permisos,
        );
    }
        
    public function print($val){
        //echo "<pre>";
        var_dump($val);exit;
    }

    /**
        Resetea los permisos para agregar los permisos que tiene cada rol por predeterminado
     */
    public function resetearPermisosXRolUsuario(int $role, string $usr): array{
        // UPDATE TIPO_USER (ROLE) BY USER
        $sql_update_user = "UPDATE {$this->table_user_tec} SET tipo_user = :role WHERE user = :user";
        $result_update_user = $this->db->statement($sql_update_user, array(':role' => $role, ':user' => $usr));

        // DELETE CURRENT PERMISSIONS
        $sql_delete = "DELETE FROM {$this->tabla} WHERE usuario = :usuario";
        $result_delete = $this->db->statement($sql_delete, array(':usuario' => $usr));

        // GET PERMISSIONS BY ROLE
        $sql_permissions_role = "SELECT menu_id FROM {$this->table_perfiles_permisos} WHERE role_id = :role_id";
        $result_permisos_perfil = $this->db->select($sql_permissions_role, array(':role_id' => $role))->data;

        return array_column($result_permisos_perfil, "menu_id");
        
    }

    /**
        Este metodo tambien se usa en la carga masiva de usuarios
        GestorUsuariosController.php
     */
    public function adicionarPermisos(array $usuarios, array $permisos, $role = null)
    {
        global $fechaLong;

        $response = array(
            "status" => true,
            "message" => "Se actualizaron los datos",
        );

        foreach ($usuarios as $usr) {
            $permisosSql = implode("','", $permisos);

            //obtiene los permisos del usuario hasta ese momento
            $sql = "SELECT * FROM {$this->tabla} WHERE usuario = '$usr' AND menu_id IN ('$permisosSql')";
                    
            $res = $this->db->select($sql);
            
            $permisosActuales = array();
            $permisosAgregar = array();

            $response["sqlPe"] = $sql;

            foreach ($res->data as $row) {
                $permisosActuales[] = $row["menu_id"];
            }

            // GET PERMISSIONS BY ROLE
            if($role != null) {
                $permisosAgregar = $this->resetearPermisosXRolUsuario((int)($role ?? 0), $usr);
            } else {
                $permisosAgregar = array_diff($permisos, $permisosActuales);
            }

            // INSERT t2_acceso_usuarios
            $sqlIns = "INSERT INTO {$this->tabla}(usuario,menu_id) VALUES";

            if (count($permisosAgregar) > 0) {
                $permisosAgregarSql = array();

                foreach ($permisosAgregar as $per) {
                    $permisosAgregarSql[] = "('$usr','$per')";
                }

                $sqlIns .= implode(",", $permisosAgregarSql);
                $sqlRes[] = $sqlIns;
                $this->db->statement($sqlIns);
            }
            $queryLog = "INSERT INTO t2_acceso_usuario_log(menus,usuario,usuario_accion,accion,fecha_registro)
                VALUES(:menu,:usuario,:usuario_sesion,:accion,'{$fechaLong}')";
            $this->db->statement($queryLog, array(
                ":menu" => implode(",", array_unique($permisos)),
                ":usuario" => $usr,
                ":usuario_sesion" => Session::user()->username,
                ":accion" => "ADICIONAR",
            ));
        }
        
        $response["ins"] = $sqlRes;
        $response["permisos"] = $permisos;
        $response["actuales"] = $permisosActuales;
        return $response;
    }
    public function asignarPermisos($usuarios, $permisos, $role = null)
    {
        global $fechaLong;
        $response = array(
            "status" => true,
            "message" => "Se actualizaron los datos",
        );

        $usuSql = implode("','", $usuarios);

        $queryDel = "DELETE FROM {$this->tabla} WHERE usuario IN ('$usuSql')";
        $resDel = $this->db->statement($queryDel);
        if (!$resDel->status) {
            return array(
                "status" => false,
                "message" => "Error al asignar los permisos",
            );
        }
        try {
            foreach ($usuarios as $usr) {
                $permisosAgregarSql = array();

                if($role != null) {
                    // UPDATE TIPO_USER (ROLE) BY USER
                    $sql_update_user = "UPDATE {$this->table_user_tec} SET tipo_user = :role WHERE user = :user";

                    $result_update_user = $this->db->statement($sql_update_user, array(':role' => $role, ':user' => $usr));
                    // GET PERMISSIONS BY ROLE
                    $sql_permissions_role = "SELECT menu_id FROM {$this->table_perfiles_permisos} WHERE role_id = :role_id";

                    $result_permisos_perfil = $this->db->select($sql_permissions_role, array(':role_id' => $role))->data;

                    foreach($result_permisos_perfil as $row) {
                        $per = $row["menu_id"];

                        $permisosAgregarSql[] = "('$usr','$per')";
                    }
                } else {
                    foreach ($permisos as $per) {
                        $permisosAgregarSql[] = "('$usr','$per')";
                    }
                }

                $sqlIns = "INSERT INTO {$this->tabla}(usuario,menu_id) VALUES";

                $sqlIns .= implode(",", $permisosAgregarSql);
                $sqlRes[] = $sqlIns;
                $this->db->statement($sqlIns);

                $queryLog = "INSERT INTO t2_acceso_usuario_log(menus,usuario,usuario_accion,accion,fecha_registro)
                    VALUES(:menu,:usuario,:usuario_sesion,:accion,'{$fechaLong}')";

                $this->db->statement($queryLog, array(
                    ":menu" => implode(",", array_unique($permisos)),
                    ":usuario" => $usr,
                    ":usuario_sesion" => Session::user()->username,
                    ":accion" => "ASIGNAR",
                ));
            }
        } catch (Exception $e) {
            $queryDel = "DELETE FROM {$this->tabla} WHERE usuario IN ('$usuSql')";
            $resDel = $this->db->statement($queryDel);

            $queryInsTemp = "INSERT INTO {$this->tabla} SELECT * FROM {$this->tabla}_temp";
            $this->db->statement($queryInsTemp);
            $response["status"] = false;
            $response["message"] = "Error al asignar los permisos";
            $response["error"] = $e->getMessage();
        }
        // $response["ins"] = $sqlRes;
        return $response;
    }
    public function usuariosExcel($archivo)
    {
        require_once '/var/www/t2/phpexcel/PHPExcel.php';
        $tipoArchivo = PHPExcel_IOFactory::identify($archivo);
        $objReader = PHPExcel_IOFactory::createReader($tipoArchivo);
        $excel = $objReader->load($archivo);
        $sheet = $excel->getSheet(0);
        $highestRow = $sheet->getHighestRow();

        $usuarios = array();
        for ($i = 2; $i <= $highestRow; $i++) {
            $usuario = $sheet->getCell('A' . $i)->getValue();
            if (!!$usuario) {
                $usuarios[] = $usuario;
            }
        }
        return $usuarios;
    }

    private function toArray($array)
    {
        sort($array);
        foreach ($array as $key => $mod) {
            sort($array[$key]["children"]);
        }
        return $array;
    }
}
