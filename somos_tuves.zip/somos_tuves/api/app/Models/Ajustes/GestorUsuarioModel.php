<?php

namespace App\Models\Ajustes;

require_once '/var/www/html/somos_tuves/composer/vendor/autoload.php';

use App\Models\DB;
use App\Models\GeneralModel;
use App\Models\Ajustes\PermisosKT2Model;
use App\Utils\Password;
use App\Utils\Util;
// use PHPExcel_IOFactory;
use PhpOffice\PhpSpreadsheet\IOFactory;

class GestorUsuarioModel
{

    private $db;
    private $generalModel;
    private $permisoModel;
    public function __construct()
    {
        $this->db = new DB();
        $this->generalModel = new GeneralModel();
        $this->permisoModel = new PermisosKT2Model();
    }
    /**
     * Funcion que genera un usuario de acuerdo al nombre y apellido
     */
    private static function generarUsuario(string $nombre, string $apellido): string
    {
        $apellido = strtolower(trim($apellido));

        $lst_nombre = explode(" ", strtolower(trim($nombre)));
        $lst_apellidos = explode(" ", $apellido);

        $posiblesParticulas = ["de", "del", "la", "las", "los"]; // mantener el orden para extraer estas palabras
        $letra_apellido = [];
        foreach ($lst_apellidos as $key => $value) {
            $value = strtolower(trim($value));
            if (in_array($value, $posiblesParticulas)) {
                $letra_apellido[] = $value;
            }
        }

        $regex = "/^(?:de la |de las |de los |de |del )?(.*)$/i"; //aqui ignoramos estas palabras para que solo nos de el apellido

        $encontrado = [];
        if (preg_match($regex, $apellido, $matches)) { //si encontramos que existen las palabras
            $encontrado = $matches[1];
        } else {
            $encontrado = $apellido; //mantenemos el apellido que viene del parametro
        }
        $nombre_asignado = $lst_nombre[0] ?? ''; //siempre el primer nombre
        $apellido_asignado = implode("", $letra_apellido) . explode(" ", $encontrado)[0]; //juntamos la letra con el apellido

        return $nombre_asignado . "." . $apellido_asignado;
    }
    public function validarExcel($archivo, $request)
    {
        /*$tipoArchivo = PHPExcel_IOFactory::identify($archivo);
        $objReader = PHPExcel_IOFactory::createReader($tipoArchivo);
        $excel = $objReader->load($archivo);
        $sheet = $excel->getSheet(0);*/

        $spreadsheet = IOFactory::load($archivo);
        $sheet = $spreadsheet->getActiveSheet();
        $highestRow = $sheet->getHighestRow();

        $usuarios = array();
        $perfiles = $this->generalModel->listarPerfiles();
        $usuariosArr = array();
        $rutArr = array();
        for ($i = 2; $i <= $highestRow; $i++) {
            $pass = Password::generate();
            $usuario = array(
                "id_temp" => $i - 1,
                "nombre" => strtoupper(Util::replaceSpecialCharactersFull($sheet->getCell('A' . $i)->getValue())),
                "apellido" => strtoupper(Util::replaceSpecialCharactersFull($sheet->getCell('B' . $i)->getValue())),
                "rut" => $sheet->getCell('C' . $i)->getValue(),
                "usuario" => self::generarUsuario($sheet->getCell('A' . $i)->getValue(), $sheet->getCell('B' . $i)->getValue()),
                "perfil" => (int)($request->perfiles ?? 0),
                "empresa_aliada" => $request->empresa_aliada ?? '',
                "tipo_ejecutivo" => $request->tipo_ejecutivo ?? 'RESIDENCIAL',
                "password" => $pass->password,
                "password_hash" => $pass->hash,
                "observaciones" => array(),
            );
            if (!$usuario["rut"]) {
                $usuario["observaciones"][] = "Sin rut";
            }
            $usuariosArr[] = $usuario["usuario"];
            $rutArr[] = $usuario["rut"];
            $usuarios[] = $usuario;
        }
        $usuariosSql = implode("','", $usuariosArr);
        $rutSql = implode("','", $rutArr);

        $query = "SELECT user,rut_tecnico rut,activo FROM user_tec WHERE user IN ('{$usuariosSql}') OR rut_tecnico IN ('{$rutSql}')";
        $usuRes = $this->db->select($query);
        $usuResArr = array();
        $estadosUsu = array();
        foreach ($usuRes->data as $usu) {
            $usuResArr["usuarios"][] = $usu['user'];
            $usuResArr["rut"][] = $usu['rut'];

            $estadosUsu[$usu["user"]] = $usu['activo'];
            $estadosUsu[$usu["rut"]] = $usu['activo'];
        }

        foreach ($usuarios as $key => $usuario) {
            if (isset($usuResArr["usuarios"]) && in_array($usuario["usuario"], $usuResArr["usuarios"])) {
                $usuarios[$key]["observaciones"][] = "El usuario ya existe";
            }
            if (isset($usuResArr["rut"]) && in_array($usuario["rut"], $usuResArr["rut"])) {
                $usuarios[$key]["observaciones"][] = "El documento $usuario[rut], ya se encuentra registrado";
            }
            if ($estadosUsu[$usuario["usuario"]] == "-1" || $estadosUsu[$usuario["rut"]] == "-1") {
                $usuarios[$key]["observaciones"][] = "El usuario se encuentra eliminado";
            }
        }

        return array(
            "status" => true,
            "data" => $usuarios,
        );
    }
    public function validarUsuario($request)
    {
        $user = $request->all();
        $query = "SELECT user,rut_tecnico rut,activo FROM user_tec WHERE user = :usuario OR rut_tecnico = :rut";
        $res = $this->db->find($query, array(
            ":usuario" => $user["usuario"],
            ":rut" => $user["rut"],
        ));
        $user["observaciones"] = array();
        if ($res->data["rut"] == $user["rut"]) {
            $rut = $res->data["rut"];
            $user["observaciones"][] = "El numero de documento $rut, ya se encuentra registrado";
        }
        if ($res->data["user"] == $user["usuario"]) {
            $user["observaciones"][] = "El usuario ya existe";
        }
        if ($res->data["activo"] == "-1") {
            $user["observaciones"][] = "El usuario se encuentra eliminado";
        }
        $user["disponible"] = count($user["observaciones"]) == 0;
        return array(
            "status" => true,
            "data" => $user,
        );
    }

    public function permisosPorUsuarioModel(array $usuarios, string $usuario_modelo, $rol = null)
    {
        //EXTRAEMOS LOS ID DE LOS PERMISOS QUE TIENE EL USUARIO MODELO
        $query = "SELECT s.id FROM t2_menu s
            INNER JOIN t2_acceso_usuario ac ON s.id = ac.menu_id
            WHERE s.estado = 1 AND s.nombre != '' AND ac.usuario = :usuario_modelo";

        $resultPermisos = $this->db->select($query, array(":usuario_modelo" => $usuario_modelo,));
        $permisos = array();
        foreach ($resultPermisos->data as $per) {
            $permisos[] = $per["id"];
        }

        return $this->permisoModel->adicionarPermisos($usuarios, $permisos, $rol);
    }
    public function colocarPermisosXRol(array $usuarios, int $rol){
        return $this->permisoModel->asignarPermisos($usuarios, [], $rol);
    }
}
