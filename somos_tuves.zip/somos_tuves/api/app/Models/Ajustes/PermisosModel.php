<?php
namespace App\Models\Ajustes;

use App\Models\DB;
use PHPExcel_IOFactory;
use App\Models\Session;
use Exception;

class PermisosModel{

    private $db;
    public function __construct(){
        $this->db = new DB();
    }
    public function adicionarPermisos($usuarios,$permisos){
        
        $response = array(
            "status" => true,
            "message" => "Se actualizaron los datos",
        );
        foreach($usuarios as $usr){
            $permisosSql = implode("','",$permisos);
            $sql = "SELECT * FROM t2_acceso_usuario 
                    WHERE usuario = '$usr'
                    AND menu_id IN ('$permisosSql')";
            $res = $this->db->select($sql);
            $permisosActuales = array();
            foreach($res->data as $row){
                $permisosActuales[] = $row["menu_id"];
            }
            $sqlIns = "INSERT INTO t2_acceso_usuario(usuario,menu_id) VALUES";
            $permisosAgregar = array_diff($permisos,$permisosActuales);
            if(count($permisosAgregar) > 0){
                $permisosAgregarSql = array();
                foreach($permisosAgregar as $per){
                    $permisosAgregarSql[]= "('$usr','$per')";
                }
                $sqlIns.= implode(",",$permisosAgregarSql);
                $sqlRes[] = $sqlIns;
                $this->db->statement($sqlIns);
                
            }
            $queryLog = "INSERT INTO t2_acceso_usuario_log(menus,usuario,usuario_accion,accion,fecha_registro)
                VALUES(:menu,:usuario,:usuario_sesion,:accion,NOW())";
            $this->db->statement($queryLog,array(
                ":menu" => implode(",",array_unique($permisos)),
                ":usuario" => $usr,
                ":usuario_sesion" => Session::user()->username,
                ":accion" => "ADICIONAR",
            ));
        }
        return $response;
    }
    public function asignarPermisos($usuarios,$permisos){
        $response = array(
            "status" => true,
            "message" => "Se actualizaron los datos",
        );
        $usuSql = implode("','",$usuarios);
        
        //Tabla temporal para regresar los permisos en caso suceda un error
        $queryTemp = "CREATE TEMPORARY TABLE t2_acceso_usuario_temp
                      SELECT * FROM t2_acceso_usuario WHERE usuario IN ('$usuSql')";
        $resTemp =   $this->db->statement($queryTemp);
        if(!$resTemp->status){
            return array(
                "status" => false,
                "message" => "Error al asignar los permisos",
            );
        }
        $queryDel = "DELETE FROM t2_acceso_usuario WHERE usuario IN ('$usuSql')";
        $resDel = $this->db->statement($queryDel);
        if(!$resDel->status){
            return array(
                "status" => false,
                "message" => "Error al asignar los permisos",
            );
        }
        try{
            foreach($usuarios as $usr){
                
                $sqlIns = "INSERT INTO t2_acceso_usuario(usuario,menu_id) VALUES";
                $permisosAgregarSql = array();
                foreach($permisos as $per){
                    $permisosAgregarSql[]= "('$usr','$per')";
                }
                $sqlIns.= implode(",",$permisosAgregarSql);
                $sqlRes[] = $sqlIns;
                $this->db->statement($sqlIns);
    
                $queryLog = "INSERT INTO t2_acceso_usuario_log(menus,usuario,usuario_accion,accion,fecha_registro)
                    VALUES(:menu,:usuario,:usuario_sesion,:accion,NOW())";
                
                $this->db->statement($queryLog,array(
                    ":menu" => implode(",",array_unique($permisos)),
                    ":usuario" => $usr,
                    ":usuario_sesion" => Session::user()->username,
                    ":accion" => "ASIGNAR",
                ));   
            }
        }catch(Exception $e){
            $queryDel = "DELETE FROM t2_acceso_usuario WHERE usuario IN ('$usuSql')";
            $resDel = $this->db->statement($queryDel);

            $queryInsTemp = "INSERT INTO t2_acceso_usuario
                             SELECT * FROM t2_acceso_usuario_temp";
            $this->db->statement($queryInsTemp);
            $response["status"] = false;
            $response["message"] = "Error al asignar los permisos";
            $response["error"] = $e->getMessage();
        }
        return $response;
    }
    public function usuariosExcel($archivo){
        require_once '/var/www/t2/phpexcel/PHPExcel.php';
        $tipoArchivo = PHPExcel_IOFactory::identify($archivo);
        $objReader = PHPExcel_IOFactory::createReader($tipoArchivo);
        $excel = $objReader->load($archivo);
        $sheet = $excel->getSheet(0);
        $highestRow = $sheet->getHighestRow();

        $usuarios = array();
        for ($i = 2; $i <= $highestRow; $i++) {
            $usuario = $sheet->getCell('A' . $i)->getValue();
            if(!!$usuario){
                $usuarios[] = $usuario;
            }
        }
        return $usuarios;
    }
}