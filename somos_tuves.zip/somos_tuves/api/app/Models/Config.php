<?php
namespace App\Models;

class Config{

    private static $rutaEstadoBandeja = "/var/www/t2/app/Logs/estado_bandeja_automatica";

    public static function estadoBandeja(){
        $estado = file_get_contents(self::$rutaEstadoBandeja);
        return $estado;
    }
    public static function actualizarBandeja(){
        $estado = self::estadoBandeja();
        $nuevoEstado = $estado == "ACTIVADO"?"DESACTIVADO":"ACTIVADO";
        file_put_contents(self::$rutaEstadoBandeja, $nuevoEstado);
    }

}
