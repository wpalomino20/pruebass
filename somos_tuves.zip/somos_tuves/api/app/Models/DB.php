<?php

namespace App\Models;

use mysqli;
use PDO;
use stdClass;

class DB
{

    private $db;
    public function __construct()
    {
        global $host, $user, $pass;

        $dsn = "mysql:dbname=somos_tuves;host=$host";
        $this->db = new PDO(
            $dsn,
            $user,
            $pass,
            array(
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"
            )
        );
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }


    public function select($query, $params = array())
    {
        $res = $this->bindAll($query, $params);
        $res->data = array();
        if (isset($res->stmt)) {
            $res->data = $res->stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        unset($res->stmt);
        return $res;
    }
    public function selectObject($query, $params = array())
    {
        $res = $this->bindAll($query, $params);
        $res->data = array();
        if (isset($res->stmt)) {
            $res->data = $res->stmt->fetchAll(PDO::FETCH_OBJ);
        }
        unset($res->stmt);
        return $res;
    }

    public function find($query, $params = array())
    {
        $res =  $this->select($query, $params);
        if (isset($res->data[0])) {
            $res->data = $res->data[0];
        } else {
            $res->data = array();
        }
        return $res;
    }


    public function statement($query, $params = array())
    {
        $res = $this->bindAll($query, $params);
        //Error de typo, falta cambiar en algunos controladores
        $res->affeted_rows = $res->stmt->rowCount();

        $res->affected_rows = $res->stmt->rowCount();
        $res->insert_id = $this->db->lastInsertId();
        unset($res->stmt);
        return $res;
    }


    private function bindAll($query, $params)
    {
        $res = new stdClass();
        $res->message = "No Errors";
        $res->status = true;
        $stmt = $this->db->prepare($query);
        $res->status = $stmt->execute($params);
        $res->stmt = $stmt;
        return $res;
    }


    public function statementInsert($table, $fields)
    {
        $query = $this->buildInsertStmt($table, $fields);
        $params = array();
        foreach ($fields as $key => $value) {
            $params[":$key"] = $value;
        }
        return $this->statement($query, $params);
    }


    public function statementUpdate($table, $fields, $where)
    {
        $query = $this->buildUpdateStmt($table, $fields, $where);
        $params = array();
        foreach ($fields as $key => $value) {
            $params[":$key"] = $value;
        }
        foreach ($where as $key => $value) {
            if (is_array($value)) {
                $params[":{$key}_upt"] = $value[1];
            } else {
                $params[":{$key}_upt"] = $value;
            }
        }

        return $this->statement($query, $params);
    }


    public function buildUpdateStmt($table, $fields, $where)
    {
        $fieldsSql = array();
        foreach ($fields as $key => $value) {
            $fieldsSql[] = "`$key` = :$key";
        }
        $whereSql = array();
        foreach ($where as $key => $value) {
            if (is_array($value)) {
                $whereSql[] = sprintf("`%s` %s :%s_upt", $key, $value[0], $key);
            } else {
                $whereSql[] = "`$key` = :{$key}_upt";
            }
        }
        $sql = strtr("UPDATE %table
                SET %fields
                WHERE %where
                LIMIT 1", array(
            "%table" => $table,
            "%fields" => implode(",", $fieldsSql),
            "%where" => implode(" AND ", $whereSql),
        ));
        return $sql;
    }


    public function buildInsertStmt($table, $fields)
    {

        $placeholders = array();
        foreach ($fields as $key => $value) {
            $placeholders[] = ":$key";
        }
        $sql = strtr(
            "INSERT INTO %table (%fields) VALUES(%placeholders)",
            array(
                "%table" => $table,
                "%fields" => implode(",", array_keys($fields)),
                "%placeholders" => implode(",", $placeholders),
            )
        );
        return $sql;
    }


    public function error()
    {
        $errors = $this->db->errorInfo();
        return $errors[2];
    }
}
