<?php
namespace App\Models;

use App\Http\JWTAuth;
use App\Http\Request;
use App\Utils\Password;

class AuthModel{

    private $db;
    private $jwt;
    private $user;
    public function __construct(){
        $this->db = new DB();
        $this->jwt = new JWTAuth();
    }

    public function userHasValidToken(){

        # Verificar el usuario tenga un token, y que sea valido de un día de vida.
        $res = $this->get();
        if(!isset($res->data["token"])){
            $this->unableUserToken();
            return false;
        }
        return true;
    }
    public function renovarToken(){
        $query = "UPDATE usuario_token
                  SET fecha_ultimo_uso = NOW()
                  WHERE usuario = :usuario AND activo = 1"; 
        $this->db->statement($query,array(
            ":usuario" => $this->user,
        ));

        $sqlUpt = "UPDATE user_tec SET fecha_ultima_visita = NOW() WHERE user = :user";
        $this->db->statement($sqlUpt,array(
            ":user" => $this->user,
        ));
        return $this;
    }
    public function generateNewToken($data){
        $data["timestamp"] = date("Y_m_d_h_i_s");
        $token = $this->jwt->generate($data);
        
        $ip = obtenerIPCliente();
        $query = "INSERT INTO log(user,fecha_ingreso,navegador,ip,url_ingreso)
                  VALUES(:usuario,NOW(),:navegador,:ip,:url_ingreso)";

        $url_ingreso = !!$_SERVER["HTTP_ORIGIN"]?$_SERVER["HTTP_ORIGIN"]:$_SERVER["SERVER_NAME"];
        $this->db->statement($query,array(
            ":usuario" => $data["username"],
            ":navegador" => $_SERVER['HTTP_USER_AGENT'],
            ":ip" => $ip,
            ":url_ingreso" => $url_ingreso,
        ));

        $sqlIn = "INSERT INTO usuario_token(usuario,token,fecha_creacion,fecha_ultimo_uso)
                    VALUE(
                        :usuario,
                        :token,
                        NOW(),
                        NOW()
                    ) ON DUPLICATE KEY UPDATE fecha_ultimo_uso = NOW(),activo = 1";
        $res = $this->db->statement($sqlIn,array(
            ":usuario" => $data["username"],
            ":token" => $token,
        ));

        $sqlUpt = "UPDATE user_tec SET fecha_ultima_visita = NOW() WHERE user = :user";
        $this->db->statement($sqlUpt,array(
            ":user" => $data["username"],
        ));
        return $this;
    }
    public function get(){
        $query = "SELECT 
                `user`,
                pass, 
                p.id AS role,
                p.nombre tipo_user,
                rut_tecnico, 
                is_online, 
                empresa_aliada, 
                theme, 
                type_menu,
                token,
                CONCAT_WS(' ',nombre_tec,ape_tec) nombres,
                NOW() login,
                is_developer,
                bloqueado_ingreso,
                l.mes,
                l.instalacion,
                l.reparacion,
                l.`upgrade`,
                l.calidad_terreno,
                l.cuartil_tecnico,
                IF(l.id IS NULL, 0, 1) AS isCuartil5
                FROM usuario_token ut
                INNER JOIN user_tec u ON ut.usuario = u.`user`
                INNER JOIN perfiles p ON p.id = u.tipo_user
                LEFT JOIN lista_negra_tecnicos l ON l.rut_tec = u.rut_tecnico
                WHERE `user` = :user
                AND u.activo = 1 AND ut.activo = 1
                AND ut.fecha_ultimo_uso BETWEEN DATE_SUB(NOW(),INTERVAL 1 DAY) AND NOW()";
        $res = $this->db->find($query, array(
            ":user" => $this->user,
        ));
        $data = $res->data;
        if(!isset($data["user"])){
            return array(
                "message" => "Usuario invalido",
                "status" => false,
            );
        }
        $res->message = "Correcto";

        $fileNameIndex = $_SERVER["DOCUMENT_ROOT"]."/t2/t2_react/branches/development/index.html";
        $dateVersion = date("Y_m_d_H_i_s");
        if(file_exists($fileNameIndex)){
            $dateVersion = date("Y_m_d_H_i_s",filemtime($fileNameIndex));
        }

        $res->data = array(
            "user" => array(
                "date_version" => $dateVersion,
                "username" => $data["user"],
                "tipo_user" => $data["tipo_user"],
                "dni" => $data["rut_tecnico"],
                "empresa_aliada" => $data["empresa_aliada"],
                "nombres" => $data["nombres"],
                "aliado" => $data["empresa_aliada"],
                "is_developer" => $data["is_developer"] == "1",
                "bloqueado_ingreso" => $data["bloqueado_ingreso"] == "1",
                "isCuartil5" => !!$data["isCuartil5"],
                'roleId'  => $data["role"],
                "cuartil" => array(
                    "mes" => $data["mes"],
                    "instalacion" => $data["instalacion"],
                    "reparacion" => $data["reparacion"],
                    "upgrade" => $data["upgrade"],
                    "calidad_terreno" => $data["calidad_terreno"],
                    "cuartil_tecnico" => $data["cuartil_tecnico"],
                ),
                "permisos" => $this->permisos($data["user"]),
                "permisos_test" => $this->permisos_V2($data["user"])
            ),
            "token" => $data["token"],
        );
        return $res;
    }
    public function validToken($token){
        $sqlToken = "SELECT * FROM usuario_token
                     WHERE token = :auth_token AND activo = 1";
        $res = $this->db->find($sqlToken,array(
            ":auth_token" => $token,
        ));
        if(!$res->data){
            return false;
        }
        $this->user = $res->data["usuario"];
        return $this->jwt->validateToken($token);
    }
    public function unableUserToken(){
        $query = "UPDATE usuario_token 
                    SET activo = 0 
                    WHERE usuario = :usuario";
        $this->db->statement($query,array(
            ":usuario" => $this->user
        ));
    }
    public function revokeToken($token){
        if(!$this->validToken($token)){
            return array(
                "message" => "Credenciales Invalidas",
                "status" => false,
            );
        }
        $query = "UPDATE usuario_token 
                    SET activo = 0 
                    WHERE usuario = :usuario AND activo = 1";
        $res = $this->db->statement($query,array(
            ":usuario" => $this->user
        ));
        $res->message = "Se invalido las credenciales";
        unset($res->stmt);

        return $res;
    }
    public function user(){
        // $headerRequest = apache_request_headers();
        // $token = $headerRequest["authorization"];
        $request = new Request();
        $token = $request->Authorization;
        $validation = $this->validToken($token);
        if($validation){
            $res = $this->get();
            return $res->data["user"];
        }
        return;
    }

    public function validUsernameAndPassword($user,$password){
        $this->user = $user;

        $query = "SELECT user,pass FROM user_tec
                  WHERE user = :user";    

        $res = $this->db->find($query,array(
            ":user" => $user
        ));
        return Password::validate($password,$res->data["pass"]);
    }
    public function permisos($user){
        $query = "SELECT s2.id,s2.nombre,s2.ruta,s2.nivel,s2.icono,s2.menu_id_padre,
                         s1.nombre nombre_padre,s1.ruta ruta_padre,s1.icono icono_padre,s2.estado_desarrollo
                  FROM t2_menu s2
                  INNER JOIN t2_menu s1 ON s2.menu_id_padre = s1.id 
                  INNER JOIN t2_acceso_usuario ac ON s2.id = ac.menu_id
                  WHERE s2.estado = 1 AND s1.estado = 1 AND ac.usuario = :usuario and s2.nivel!=0 and s1.nivel!=0
                  ORDER BY s1.orden,s2.estado_desarrollo";
        $res = $this->db->select($query,array(
            ":usuario" => $user
        ));
        $data = $res->data;
        $arr = array();

        foreach($data as $menu){
            $arr[$menu["menu_id_padre"]]["label"] = $menu["nombre_padre"];
            $arr[$menu["menu_id_padre"]]["path"] = $menu["ruta_padre"];
            $arr[$menu["menu_id_padre"]]["icon"] = $menu["icono_padre"];
            $arr[$menu["menu_id_padre"]]["children"][] = array(
                "label" => $menu["nombre"],
                "path" => $menu["ruta"],
                "icon" => $menu["icono"],
                "status" => $menu["estado_desarrollo"],
            );
        }
        $arr = array_values($arr);
        return $arr;
    }
	
	public function permisos_V2($user){
        $query = "select 
				s1.id,s1.nombre,s1.ruta,s1.icono,s1.estado_desarrollo,s1.menu_id_padre,s1.nivel,
				(select menu_id_padre from t2_menu as menu0 where menu0.id = s1.menu_id_padre ) as idPadre
			FROM
				t2_acceso_usuario as  ac
			INNER JOIN t2_menu s1  ON ac.menu_id = s1.id
				where ac.usuario =:usuario ORDER by s1.nivel,s1.nombre,s1.ruta";
					
        $res = $this->db->select($query,array(
            ":usuario" => $user
        ));
        $data = $res->data;
        $arr = array();

        foreach($data as $menu){
			
			if($menu["nivel"]=='0'){ //nivel 0
				$arr[$menu["id"]]["id"] = $menu["id"];
				$arr[$menu["id"]]["label"] = $menu["nombre"];
				$arr[$menu["id"]]["path"] = $menu["ruta"];
				$arr[$menu["id"]]["icon"] = $menu["icono"];
				$arr[$menu["id"]]["status"] = $menu["estado_desarrollo"];;
			}else{
				if($menu["nivel"]=='1'){ //nivel 1
				
					if($menu["menu_id_padre"]!=0){
	
						$arr[$menu["menu_id_padre"]]["children"][]= array(
							"id"=>$menu["id"],
							"label"=>$menu["nombre"],
							"path"=>$menu["ruta"],
							"icon"=>$menu["icono"],
							"status"=>$menu["estado_desarrollo"]
						);
					}else{
						$arr[$menu["id"]]["id"] = $menu["id"];
						$arr[$menu["id"]]["label"] = $menu["nombre"];
						$arr[$menu["id"]]["path"] = $menu["ruta"];
						$arr[$menu["id"]]["icon"] = $menu["icono"];
						$arr[$menu["id"]]["status"] = $menu["estado_desarrollo"];
					}
				}else{ //nivel 2
				
					if($menu["idPadre"]!=0){

						$keySearch='';
						foreach($arr[$menu["idPadre"]]["children"] as $key =>$value){
							if($value['id']==$menu["menu_id_padre"]){	
								$keySearch=$key;
								break;
							}
						}
						
						
						$arr[$menu["idPadre"]]["children"][$keySearch]["children"][] = array(
							"id"=>$menu["id"],
							"label"=>$menu["nombre"],
							"path"=>$menu["ruta"],
							"icon"=>$menu["icono"],
							"status"=>$menu["estado_desarrollo"]
						);						
					}else{

						$keySearch='';
						foreach($arr[$menu["menu_id_padre"]]["children"] as $key =>$value){
							if($value['id']==$menu["menu_id_padre"]){	
								$keySearch=$key;
								break;
							}
						}
						
						$arr[$menu["menu_id_padre"]]["children"][$keySearch]["children"][] = array(
							"id"=>$menu["id"],
							"label"=>$menu["nombre"],
							"path"=>$menu["ruta"],
							"icon"=>$menu["icono"],
							"status"=>$menu["estado_desarrollo"]);	
					}
					
				}
			}
		
		
        }

        $arr = array_values($arr);
        return $arr;
    }

    /* Alternate to Multinvel */
    public function getTreeMenu($id = 0, $user = "") {
        // $query = "SELECT * FROM t2_menu WHERE menu_id_padre = {$id} ORDER BY nombre DESC ";
        $query = "
            SELECT
            	m.id,
                m.nivel,
            	m.nombre AS label,
            	m.ruta AS path,
            	m.icono AS icon,
            	estado_desarrollo AS status
            FROM
            	t2_menu m
            INNER JOIN t2_acceso_usuario ac ON ac.menu_id = m.id
            WHERE
            	menu_id_padre = {$id} AND ac.usuario LIKE '{$user}'
            ORDER BY
            	nombre DESC;
        ";
        
        $menu = array();
    
        $results = $this->db->select($query);
    
        foreach($results->data as $d) {

            $children = $this->getTreeMenu($d['id'], $user);
    
            if(!empty($children)) {
                $menu[] = array_merge(array(
                    'nivel' => $d['nivel'],
                    'label' => $d['label'],
                    'path' => $d['path'],
                    'icon' => $d['icon'],
                    'status' => $d['status']
                ), array('children' => $children));
            } else {
                $menu[] = array(
                    'nivel' => $d['nivel'],
                    'label' => $d['label'],
                    'path' => $d['path'],
                    'icon' => $d['icon'],
                    'status' => $d['status']
                );
            }
        }
    
        return $menu;        
    }

    public function refreshToken($user){
        $query = "UPDATE usuario_token 
                    SET fecha_ultimo_uso = NOW()
                    WHERE usuario = :usuario AND activo = 1";
        $res = $this->db->statement($query,array(
            ":usuario" => $this->user
        ));
    }
}