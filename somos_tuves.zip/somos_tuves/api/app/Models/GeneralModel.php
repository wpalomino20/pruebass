<?php
namespace App\Models;

use App\Models\DB;

class GeneralModel {

    private $db;
    public function __construct()
    {
        $this->db = new DB();
    }
    public function listarPerfiles(){
        $sql = "SELECT id `key`, nombre `value` FROM perfiles WHERE nombre != ' ' ORDER BY nombre";

        return $this->db->select($sql);
    }
    public function listarEmpresasAliadas(){
        $sql = "SELECT nombre_empresa `key`,nombre_empresa `value` FROM t2_empresas_aliadas WHERE activo = '1' ORDER BY nombre_empresa";

        return $this->db->select($sql);
    }
    public function listarTipoEjecutivo(){
        return array(
            array(
                "key" => "EMPRESA",
                "value" => "EMPRESA",
            ),
            array(
                "key" => "RESIDENCIAL",
                "value" => "RESIDENCIAL",
            ),
        );
    }
    public function buildTree($data,$niveles){

        $query = "SELECT tipo_equipo n1 ,modelo n2,doc_sis n3 FROM t2_equipos WHERE estado = 1 AND tipo_equipo = 'MODEM'";
        $equipos = $this->db->select($query)->data;

        $items_niveles = array();
        $niveles = 3;
        foreach($equipos as $row){
            for($i = 1; $i <= $niveles; $i++){
                $items_niveles["nivel_{$i}"][$row["n".($i-1)]][$row["n{$i}"]] = $row["n{$i}"];
            }
        }
        $outputArr = array();
        // for($i = 3; $i <= $niveles; $i++){
            // sort($items_niveles["nivel_{$i}"]);
            for($j = 0; $j < count($items_niveles["nivel_{$i}"]);$j++){
                $outputArr[$j]["options"] = array(
                    "value" => $items_niveles["nivel_{$i}"][$j],
                );
            }
        // }
        
        $a = array(
            array(
                "value" => "EMTA",
                "options" => array(
                    array( 
                        "value" => "KAON CG3000B",
                        "options" => array(
                            array("value" => "3.1")
                        )
                    ),
                    array( 
                        "value" => "DPC 3928S",
                        "options" => array(
                            array("value" => "3.0")
                        )
                    )
                )
            )
        );
        // return $outputArr;
        // return $items_niveles;
        // return $a[0]["options"][1]["options"][0];

    }
}