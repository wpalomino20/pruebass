<?php

    namespace App\Models\Hogar;

    use App\Models\DB;

    class ProcedimientoModel {
        public static function getById(string $id) {
            $sql = "
                SELECT
                    id,
                    nombre,
                    fecha_carga,
                    descripcion
                FROM procedimientos
                WHERE id = :id
            ";

            return (new DB())->find($sql, array(':id' => $id))->data;
        }
    }