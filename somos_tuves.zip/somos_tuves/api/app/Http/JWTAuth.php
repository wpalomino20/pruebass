<?php
namespace App\Http;
# Investigación
# https://es.stackoverflow.com/questions/105194/es-posible-usar-json-web-token-sin-instalar-con-composer
class JWTAuth{

    private $alg = "HS256";
    private $type = "JWT";
    public function __construct()
    {
    }
    private function encodedHeader(){
        
        $jsonHeader = json_encode(array(
            "alg" => $this->alg,
            "type" => $this->type
        ));
        $encoded_header = base64_encode($jsonHeader);
        return $encoded_header;
    }

    private function encodedPayload($params){
        $jsonParams = json_encode($params);
        $encoded_payload = base64_encode($jsonParams);
        return $encoded_payload;
    }
    public function generate($params){

        $headerPayload = substr($this->encodedHeader(),0,50) . '.' . substr($this->encodedPayload($params),0,50);

        //Setting the secret key
        $secreteKey = 'Konecta@2023T2';

        // Creating the signature, a hash with the s256 algorithm and the secret key. The signature is also base64 encoded.
        $signature = substr(base64_encode(hash_hmac('sha256', $headerPayload, $secreteKey, true)),0,150);

        // Creating the JWT token by concatenating the signature with the header and payload, that looks like this:
        $jwtToken = $headerPayload . '.' . $signature;
        //listing the resulted  JWT
        return $jwtToken;
    }

    public function validateToken($token){

        $secretKey = 'Konecta@2023T2';

        $jwtValues = explode('.', $token);
        
        $recievedSignature = $jwtValues[2];
        
        // $recievedHeaderAndPayload = $jwtValues[0] . '.' . $jwtValues[1];
        $recievedHeaderAndPayload = $jwtValues[0] . '.' . $jwtValues[1];
        
        
        $resultedSignature = substr(base64_encode(hash_hmac('sha256', $recievedHeaderAndPayload, $secretKey, true)),0,150);
        return $resultedSignature == $recievedSignature;
    }




}