<?php
namespace App\Http;

class Request{

    private $properties = array();
    public function __construct()
    {   
        $request = $_REQUEST;
        if(file_get_contents('php://input') != ""){
            $jsonBody = json_decode(file_get_contents('php://input'),true);
            $request = $_REQUEST;
            if(!is_null($jsonBody)){
                $request = array_merge($jsonBody,$_REQUEST);
            }
        }
        foreach($request as $key => $value){
            $this->properties[$key] = $value;
        }
    }

    public function __get($name)
    {
        if(isset($this->properties[$name]))
            return $this->properties[$name];
    }

    public function all(){
        return $this->properties;
    }

    public function __debugInfo()
    {
        return $this->properties;
    }
    
    public function file(){
        return $_FILES;
    }

}