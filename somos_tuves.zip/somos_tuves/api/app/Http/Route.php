<?php
namespace App\Http;

use App\Exceptions\MethodNotAllowedException;
use App\Exceptions\NotFoundException;
use stdClass;

class Route{

    private static $routes = array();
    private static $currentRoute;

    public static function get($route,$params){
        $routeObj = self::buildRoute($route,$params,"GET");
        self::$routes[] = $routeObj;
    }
    public static function post($route,$params){
        $routeObj = self::buildRoute($route,$params,"POST");
        self::$routes[] = $routeObj;
    }
    public static function html($route,$params){
        $routeObj = self::buildRoute($route,$params,"*","HTML");
        self::$routes[] = $routeObj;
    }
    public static function excel($route,$params,$file_name = "",$exact_name = false){
        $routeObj = self::buildRoute($route,$params,"*","EXCEL");
        $routeObj->file_name = $file_name;
        $routeObj->exact_name = $exact_name;
        self::$routes[] = $routeObj;
    }
    public static function csv($route,$params,$file_name = "",$exact_name = false){
        $routeObj = self::buildRoute($route,$params,"*","CSV");
        $routeObj->file_name = $file_name;
        self::$routes[] = $routeObj;
    }
    
    private static function buildRoute($route,$params,$method,$type = "JSON"){
        $routeObj = new stdClass;
        $routeObj->route = $route;
        $routeObj->requestMethod = $method;
        $routeObj->controller = $params[0];
        $routeObj->method = $params[1];
        $routeObj->type = $type;
        return $routeObj;
    }
    public static function run(){
        
        self::validate();
        self::executeCallback();
    }
    private static function validate(){
        $path = rtrim($_REQUEST["path"],"/");
        $route = "";
        foreach(self::$routes as $routeValue){
            if(trim($routeValue->route,"/") === $path){
                $route = $routeValue;
            }
        }
        if($route === ""){
            throw new NotFoundException("Path Not Found");
        }
        self::$currentRoute = $route;
        if($route->requestMethod === "*"){
            return;
        }
        if($_SERVER["REQUEST_METHOD"] !== $route->requestMethod){
            throw new MethodNotAllowedException("Method not allowed, available methods: ".$route->requestMethod);
        }

    }
    private static function executeCallback(){
        $request = new Request();
        $controller = self::$currentRoute->controller;
        $method = self::$currentRoute->method;
        $ctrl = new $controller();
        
        if(!method_exists($ctrl,$method)){
            throw new NotFoundException("Method: $method not exist");
        }
        $ctrl->validateMiddleware($method);
        
        $result = $ctrl->$method($request);
        if(self::$currentRoute->type === "JSON"){
            Response::json($result);
            exit;
        }
        if(self::$currentRoute->type === "HTML"){
            Response::html($result);
            exit;
        }
        if(self::$currentRoute->type === "EXCEL"){
            Response::excel($result,self::$currentRoute->file_name,self::$currentRoute->exact_name);
            exit;
        }
        if(self::$currentRoute->type === "CSV"){
            Response::csv($result,self::$currentRoute->file_name,self::$currentRoute->exact_name);
            exit;
        }
    }

}