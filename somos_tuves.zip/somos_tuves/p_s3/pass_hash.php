<?php

$options = ['cost' => 8];  // Ajusta el coste para hacer que el hashing sea m�s r�pido
$hash = password_hash("mi_contrase�a_secreta", PASSWORD_BCRYPT, $options);

?>