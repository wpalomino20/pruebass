<?php
require 'composer/vendor/autoload.php';

use Aws\S3\S3Client;
use Aws\Exception\AwsException;

$s3Client = new S3Client([
    'version' => 'latest',
    'region'  => 'us-east-1',
]);

$bucketName = 'tu-bucket';
$folderName = 'mi-carpeta/'; // La barra al final simula una carpeta

try {
    // Verificar si la carpeta existe listando objetos con ese prefijo
    $result = $s3Client->listObjectsV2([
        'Bucket' => $bucketName,
        'Prefix' => $folderName,
        'MaxKeys' => 1, // Solo necesitamos un resultado para verificar
    ]);

    if (empty($result['Contents'])) {
        // Si la carpeta no existe, crearla subiendo un objeto vac�o
        $s3Client->putObject([
            'Bucket' => $bucketName,
            'Key'    => $folderName, // Nombre de la carpeta simulado
            'Body'   => '',          // Objeto vac�o
        ]);

        echo "Carpeta '$folderName' creada correctamente.";
    } else {
        echo "La carpeta '$folderName' ya existe.";
    }
} catch (AwsException $e) {
    echo "Error: " . $e->getMessage();
}
?>
