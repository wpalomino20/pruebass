<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Subir Blob a S3</title>
</head>
<body>
    <form action="s3.php" method="POST" enctype="multipart/form-data">
        <input type="file" name="archivo" accept="image/*" required>
        <button type="submit">Subir Archivo</button>
    </form>
</body>
</html>
