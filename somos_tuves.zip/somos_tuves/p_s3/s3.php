<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


require 'composer/vendor/autoload.php';

use Aws\S3\S3Client;
use Aws\Exception\AwsException;

// Configura el cliente de S3 usando las credenciales por defecto (IAM Role, EC2, Lambda)
$s3Client = new S3Client([
    'version' => 'latest',
    'region'  => 'us-east-1',  // Cambia a tu regi�n
]);

// Datos del blob
$bucketName = 'kt2-images';
$keyName = 'archivo.jpg'; // Nombre del archivo en S3
$blob = file_get_contents('php://input'); // Si est�s recibiendo el blob desde una petici�n

try {
    // Subir el archivo a S3
    $result = $s3Client->putObject([
        'Bucket' => $bucketName,
        'Key'    => $keyName,
        'Body'   => $blob,
        'ContentType' => 'image/jpeg', // Ajusta el tipo de contenido seg�n el archivo
        //'ACL'    => 'public-read', // Si quieres que el archivo sea accesible p�blicamente
    ]);

    echo "Archivo subido exitosamente. URL: " . $result['ObjectURL'];
} catch (AwsException $e) {
    echo "Error subiendo archivo: " . $e->getMessage();
}
?>

