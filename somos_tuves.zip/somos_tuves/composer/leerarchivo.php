<?php

// Incluir el autoloader de Composer
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

// Cargar el archivo Excel
$inputFileName = 'prueba_ecommerce_subida.xls';
$spreadsheet = IOFactory::load($inputFileName);

// Obtener la hoja activa (la primera hoja)
$sheet = $spreadsheet->getActiveSheet();

// Obtener los datos de la hoja activa
$data = $sheet->toArray(null, true, true, true);

// Mostrar los datos
foreach ($data as $row) {
    echo implode(', ', $row) . PHP_EOL;  // Imprimir cada fila
}
