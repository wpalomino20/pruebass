<?php
require 'vendor/autoload.php'; // Asegúrate de haber instalado PhpSpreadsheet y tener el autoload de Composer

use PhpOffice\PhpSpreadsheet\IOFactory;

try {
    // Ruta del archivo Excel
    $inputFileName = 'ruta/al/archivo.xlsx';

    // Cargar el archivo
    $spreadsheet = IOFactory::load($inputFileName);

    // Obtener la hoja activa (por defecto la primera hoja)
    $worksheet = $spreadsheet->getActiveSheet();

    // Iterar sobre las filas
    foreach ($worksheet->getRowIterator() as $row) {
        $cellIterator = $row->getCellIterator();
        $cellIterator->setIterateOnlyExistingCells(false); // Para incluir celdas vacías

        // Recorrer las celdas de cada fila
        foreach ($cellIterator as $cell) {
            echo $cell->getValue() . "\t";
        }
        echo "\n";
    }
} catch (phpspreadsheet\Reader\Exception $e) {
    echo 'Error al cargar el archivo: ', $e->getMessage();
}
