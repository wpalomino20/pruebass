<?php

require 'vendor/autoload.php';

use Aws\CognitoIdentityProvider\CognitoIdentityProviderClient;
use Aws\Exception\AwsException;

// Configuración del cliente Cognito
$client = new CognitoIdentityProviderClient([
    'region' => 'us-east-1', // Cambia esto a tu región
    'version' => 'latest'
]);

$userPoolId = 'us-east-1_YDcGXjTu8'; // Reemplaza con tu User Pool ID
$appClientId = '6o9mnip12c7r33i54qh272c1el'; // Reemplaza con tu App Client ID

$username = $_SESSION['username']; // Recupera el nombre de usuario de la sesión
$mfaCode = $_POST['mfa'];

try {
    // Verificación del código MFA
    $result = $client->adminRespondToAuthChallenge([
        'UserPoolId' => $userPoolId,
        'ClientId' => $appClientId,
        'ChallengeName' => 'SMS_MFA',
        'ChallengeResponses' => [
            'SMS_MFA_CODE' => $mfaCode,
            'USERNAME' => $username,
        ],
    ]);

    // Manejo del acceso exitoso
    echo "Acceso exitoso! ID Token: " . $result['AuthenticationResult']['IdToken'];
    // Aquí puedes redirigir o almacenar los tokens para su uso posterior
} catch (AwsException $e) {
    // Manejo de errores
    echo "Error: " . $e->getMessage();
}
