<?php

require 'vendor/autoload.php';

use Aws\CognitoIdentityProvider\CognitoIdentityProviderClient;
use Aws\Exception\AwsException;

// Configuración del cliente Cognito
$client = new CognitoIdentityProviderClient([
    'region' => 'us-east-1', // Cambia esto a tu región
    'version' => 'latest'
]);

$userPoolId = 'us-east-1_YDcGXjTu8'; // Reemplaza con tu User Pool ID
$appClientId = '6o9mnip12c7r33i54qh272c1el'; // Reemplaza con tu App Client ID

$username = $_POST['username'];
$password = $_POST['password'];

try {
    // Autenticación
    $result = $client->adminInitiateAuth([
        'UserPoolId' => $userPoolId,
        'ClientId' => $appClientId,
        'AuthFlow' => 'ADMIN_NO_SRP_AUTH', // Usa el flujo adecuado
        'AuthParameters' => [
            'USERNAME' => $username,
            'PASSWORD' => $password,
        ],
    ]);

    // Si MFA es requerido
    if (isset($result['ChallengeName']) && $result['ChallengeName'] === 'SMS_MFA') {
        echo json_encode([
            'mfaRequired' => true,
            'challengeName' => $result['ChallengeName'],
        ]);
        exit;
    }

    // Maneja el acceso exitoso
    echo json_encode(['mfaRequired' => false]);
} catch (AwsException $e) {
    // Manejo de errores
    echo json_encode(['error' => $e->getMessage()]);
}
