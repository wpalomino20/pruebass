<!-- login.html -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h2>Iniciar sesión</h2>
    <form id="login-form" action="login.php" method="POST">
        <label for="username">Nombre de usuario:</label>
        <input type="text" id="username" name="username" required><br>

        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="password" required><br>

        <input type="submit" value="Iniciar sesión">
    </form>
    
    <!-- Formulario para el código de verificación -->
    <form id="mfa-form" action="verify.php" method="POST" style="display:none;">
        <label for="mfa">Código de verificación:</label>
        <input type="text" id="mfa" name="mfa" required><br>
        <input type="submit" value="Verificar">
    </form>

    <script>
        const loginForm = document.getElementById('login-form');
        const mfaForm = document.getElementById('mfa-form');

        loginForm.addEventListener('submit', function(event) {
            // Evita el envío del formulario hasta que se maneje la respuesta
            event.preventDefault();

            // Envía los datos a login.php
            const formData = new FormData(loginForm);

            fetch('login.php', {
                method: 'POST',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                if (data.mfaRequired) {
                    // Si se requiere MFA, muestra el formulario de MFA
                    loginForm.style.display = 'none';
                    mfaForm.style.display = 'block';
                    // Guarda el challengeName para usarlo en la verificación
                    sessionStorage.setItem('challengeName', data.challengeName);
                } else {
                    // Maneja el inicio de sesión exitoso
                    alert('Inicio de sesión exitoso.');
                    // Redirigir o hacer otra cosa
                }
            })
            .catch(error => console.error('Error:', error));
        });
    </script>
</body>
</html>
